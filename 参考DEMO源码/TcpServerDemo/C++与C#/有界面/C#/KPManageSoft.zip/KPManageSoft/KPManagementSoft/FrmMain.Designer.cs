﻿namespace KPManagementSoft
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.cMS1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.保存显示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清除显示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbDO15 = new System.Windows.Forms.GroupBox();
            this.cbWait15 = new System.Windows.Forms.CheckBox();
            this.btnExcute15 = new System.Windows.Forms.Button();
            this.lbWait15 = new System.Windows.Forms.Label();
            this.cbMode15 = new System.Windows.Forms.ComboBox();
            this.laDlyDO15 = new System.Windows.Forms.Label();
            this.labelDO15 = new System.Windows.Forms.Label();
            this.laDO15 = new System.Windows.Forms.Label();
            this.tbTimerDO15 = new System.Windows.Forms.TextBox();
            this.cbTimerDO15 = new System.Windows.Forms.CheckBox();
            this.lbD015 = new System.Windows.Forms.Label();
            this.txtWaitTime15 = new System.Windows.Forms.TextBox();
            this.lbSec15 = new System.Windows.Forms.Label();
            this.gbDO16 = new System.Windows.Forms.GroupBox();
            this.cbWait16 = new System.Windows.Forms.CheckBox();
            this.btnExcute16 = new System.Windows.Forms.Button();
            this.lbWait16 = new System.Windows.Forms.Label();
            this.cbMode16 = new System.Windows.Forms.ComboBox();
            this.laDlyDO16 = new System.Windows.Forms.Label();
            this.labelDO16 = new System.Windows.Forms.Label();
            this.laDO16 = new System.Windows.Forms.Label();
            this.tbTimerDO16 = new System.Windows.Forms.TextBox();
            this.cbTimerDO16 = new System.Windows.Forms.CheckBox();
            this.lbD016 = new System.Windows.Forms.Label();
            this.lbSec16 = new System.Windows.Forms.Label();
            this.txtWaitTime16 = new System.Windows.Forms.TextBox();
            this.gbDO14 = new System.Windows.Forms.GroupBox();
            this.cbWait14 = new System.Windows.Forms.CheckBox();
            this.btnExcute14 = new System.Windows.Forms.Button();
            this.lbWait14 = new System.Windows.Forms.Label();
            this.cbMode14 = new System.Windows.Forms.ComboBox();
            this.laDlyDO14 = new System.Windows.Forms.Label();
            this.labelDO14 = new System.Windows.Forms.Label();
            this.laDO14 = new System.Windows.Forms.Label();
            this.tbTimerDO14 = new System.Windows.Forms.TextBox();
            this.cbTimerDO14 = new System.Windows.Forms.CheckBox();
            this.txtWaitTime14 = new System.Windows.Forms.TextBox();
            this.lbD014 = new System.Windows.Forms.Label();
            this.lbSec14 = new System.Windows.Forms.Label();
            this.gbDO13 = new System.Windows.Forms.GroupBox();
            this.cbWait13 = new System.Windows.Forms.CheckBox();
            this.btnExcute13 = new System.Windows.Forms.Button();
            this.lbWait13 = new System.Windows.Forms.Label();
            this.cbMode13 = new System.Windows.Forms.ComboBox();
            this.laDlyDO13 = new System.Windows.Forms.Label();
            this.labelDO13 = new System.Windows.Forms.Label();
            this.cbTimerDO13 = new System.Windows.Forms.CheckBox();
            this.txtWaitTime13 = new System.Windows.Forms.TextBox();
            this.laDO13 = new System.Windows.Forms.Label();
            this.tbTimerDO13 = new System.Windows.Forms.TextBox();
            this.lbD013 = new System.Windows.Forms.Label();
            this.lbSec13 = new System.Windows.Forms.Label();
            this.gbDO12 = new System.Windows.Forms.GroupBox();
            this.cbWait12 = new System.Windows.Forms.CheckBox();
            this.btnExcute12 = new System.Windows.Forms.Button();
            this.cbMode12 = new System.Windows.Forms.ComboBox();
            this.laDlyDO12 = new System.Windows.Forms.Label();
            this.lbWait12 = new System.Windows.Forms.Label();
            this.labelDO12 = new System.Windows.Forms.Label();
            this.lbD012 = new System.Windows.Forms.Label();
            this.laDO12 = new System.Windows.Forms.Label();
            this.tbTimerDO12 = new System.Windows.Forms.TextBox();
            this.txtWaitTime12 = new System.Windows.Forms.TextBox();
            this.cbTimerDO12 = new System.Windows.Forms.CheckBox();
            this.lbSec12 = new System.Windows.Forms.Label();
            this.gbDO11 = new System.Windows.Forms.GroupBox();
            this.cbWait11 = new System.Windows.Forms.CheckBox();
            this.btnExcute11 = new System.Windows.Forms.Button();
            this.cbMode11 = new System.Windows.Forms.ComboBox();
            this.lbWait11 = new System.Windows.Forms.Label();
            this.laDlyDO11 = new System.Windows.Forms.Label();
            this.labelDO11 = new System.Windows.Forms.Label();
            this.lbD011 = new System.Windows.Forms.Label();
            this.cbTimerDO11 = new System.Windows.Forms.CheckBox();
            this.txtWaitTime11 = new System.Windows.Forms.TextBox();
            this.laDO11 = new System.Windows.Forms.Label();
            this.tbTimerDO11 = new System.Windows.Forms.TextBox();
            this.lbSec11 = new System.Windows.Forms.Label();
            this.gbDO10 = new System.Windows.Forms.GroupBox();
            this.cbWait10 = new System.Windows.Forms.CheckBox();
            this.btnExcute10 = new System.Windows.Forms.Button();
            this.lbWait10 = new System.Windows.Forms.Label();
            this.cbMode10 = new System.Windows.Forms.ComboBox();
            this.laDlyDO10 = new System.Windows.Forms.Label();
            this.labelDO10 = new System.Windows.Forms.Label();
            this.tbTimerDO10 = new System.Windows.Forms.TextBox();
            this.txtWaitTime10 = new System.Windows.Forms.TextBox();
            this.lbD10 = new System.Windows.Forms.Label();
            this.cbTimerDO10 = new System.Windows.Forms.CheckBox();
            this.laDO10 = new System.Windows.Forms.Label();
            this.lbSec10 = new System.Windows.Forms.Label();
            this.gbDO9 = new System.Windows.Forms.GroupBox();
            this.cbWait9 = new System.Windows.Forms.CheckBox();
            this.btnExcute9 = new System.Windows.Forms.Button();
            this.lbWait9 = new System.Windows.Forms.Label();
            this.cbMode9 = new System.Windows.Forms.ComboBox();
            this.laDlyDO9 = new System.Windows.Forms.Label();
            this.labelDO9 = new System.Windows.Forms.Label();
            this.tbTimerDO9 = new System.Windows.Forms.TextBox();
            this.lbD09 = new System.Windows.Forms.Label();
            this.txtWaitTime9 = new System.Windows.Forms.TextBox();
            this.cbTimerDO9 = new System.Windows.Forms.CheckBox();
            this.laDO9 = new System.Windows.Forms.Label();
            this.lbSec9 = new System.Windows.Forms.Label();
            this.gbDO8 = new System.Windows.Forms.GroupBox();
            this.cbWait8 = new System.Windows.Forms.CheckBox();
            this.btnExcute8 = new System.Windows.Forms.Button();
            this.cbMode8 = new System.Windows.Forms.ComboBox();
            this.lbWait8 = new System.Windows.Forms.Label();
            this.laDlyDO8 = new System.Windows.Forms.Label();
            this.labelDO8 = new System.Windows.Forms.Label();
            this.txtWaitTime8 = new System.Windows.Forms.TextBox();
            this.tbTimerDO8 = new System.Windows.Forms.TextBox();
            this.lbD08 = new System.Windows.Forms.Label();
            this.cbTimerDO8 = new System.Windows.Forms.CheckBox();
            this.laDO8 = new System.Windows.Forms.Label();
            this.lbSec8 = new System.Windows.Forms.Label();
            this.gbDO7 = new System.Windows.Forms.GroupBox();
            this.cbWait7 = new System.Windows.Forms.CheckBox();
            this.btnExcute7 = new System.Windows.Forms.Button();
            this.lbWait7 = new System.Windows.Forms.Label();
            this.cbMode7 = new System.Windows.Forms.ComboBox();
            this.laDlyDO7 = new System.Windows.Forms.Label();
            this.txtWaitTime7 = new System.Windows.Forms.TextBox();
            this.labelDO7 = new System.Windows.Forms.Label();
            this.tbTimerDO7 = new System.Windows.Forms.TextBox();
            this.lbD07 = new System.Windows.Forms.Label();
            this.cbTimerDO7 = new System.Windows.Forms.CheckBox();
            this.laDO7 = new System.Windows.Forms.Label();
            this.lbSec7 = new System.Windows.Forms.Label();
            this.gbDO6 = new System.Windows.Forms.GroupBox();
            this.cbWait6 = new System.Windows.Forms.CheckBox();
            this.btnExcute6 = new System.Windows.Forms.Button();
            this.lbWait6 = new System.Windows.Forms.Label();
            this.cbMode6 = new System.Windows.Forms.ComboBox();
            this.txtWaitTime6 = new System.Windows.Forms.TextBox();
            this.laDlyDO6 = new System.Windows.Forms.Label();
            this.labelDO6 = new System.Windows.Forms.Label();
            this.tbTimerDO6 = new System.Windows.Forms.TextBox();
            this.lbD06 = new System.Windows.Forms.Label();
            this.cbTimerDO6 = new System.Windows.Forms.CheckBox();
            this.lbSec6 = new System.Windows.Forms.Label();
            this.laDO6 = new System.Windows.Forms.Label();
            this.gbDO5 = new System.Windows.Forms.GroupBox();
            this.cbWait5 = new System.Windows.Forms.CheckBox();
            this.lbWait5 = new System.Windows.Forms.Label();
            this.btnExcute5 = new System.Windows.Forms.Button();
            this.txtWaitTime5 = new System.Windows.Forms.TextBox();
            this.cbMode5 = new System.Windows.Forms.ComboBox();
            this.laDlyDO5 = new System.Windows.Forms.Label();
            this.labelDO5 = new System.Windows.Forms.Label();
            this.tbTimerDO5 = new System.Windows.Forms.TextBox();
            this.lbSec5 = new System.Windows.Forms.Label();
            this.lbD05 = new System.Windows.Forms.Label();
            this.cbTimerDO5 = new System.Windows.Forms.CheckBox();
            this.laDO5 = new System.Windows.Forms.Label();
            this.gbDO4 = new System.Windows.Forms.GroupBox();
            this.cbWait4 = new System.Windows.Forms.CheckBox();
            this.lbWait4 = new System.Windows.Forms.Label();
            this.btnExcute4 = new System.Windows.Forms.Button();
            this.cbMode4 = new System.Windows.Forms.ComboBox();
            this.laDlyDO4 = new System.Windows.Forms.Label();
            this.labelDO4 = new System.Windows.Forms.Label();
            this.txtWaitTime4 = new System.Windows.Forms.TextBox();
            this.tbTimerDO4 = new System.Windows.Forms.TextBox();
            this.lbD04 = new System.Windows.Forms.Label();
            this.cbTimerDO4 = new System.Windows.Forms.CheckBox();
            this.laDO4 = new System.Windows.Forms.Label();
            this.lbSec4 = new System.Windows.Forms.Label();
            this.gbDO3 = new System.Windows.Forms.GroupBox();
            this.cbWait3 = new System.Windows.Forms.CheckBox();
            this.lbWait3 = new System.Windows.Forms.Label();
            this.btnExcute3 = new System.Windows.Forms.Button();
            this.cbMode3 = new System.Windows.Forms.ComboBox();
            this.laDlyDO3 = new System.Windows.Forms.Label();
            this.txtWaitTime3 = new System.Windows.Forms.TextBox();
            this.labelDO3 = new System.Windows.Forms.Label();
            this.tbTimerDO3 = new System.Windows.Forms.TextBox();
            this.lbD03 = new System.Windows.Forms.Label();
            this.cbTimerDO3 = new System.Windows.Forms.CheckBox();
            this.lbSec3 = new System.Windows.Forms.Label();
            this.laDO3 = new System.Windows.Forms.Label();
            this.gbDO2 = new System.Windows.Forms.GroupBox();
            this.cbWait2 = new System.Windows.Forms.CheckBox();
            this.lbWait2 = new System.Windows.Forms.Label();
            this.btnExcute2 = new System.Windows.Forms.Button();
            this.cbMode2 = new System.Windows.Forms.ComboBox();
            this.txtWaitTime2 = new System.Windows.Forms.TextBox();
            this.laDlyDO2 = new System.Windows.Forms.Label();
            this.labelDO2 = new System.Windows.Forms.Label();
            this.tbTimerDO2 = new System.Windows.Forms.TextBox();
            this.lbSec2 = new System.Windows.Forms.Label();
            this.cbTimerDO2 = new System.Windows.Forms.CheckBox();
            this.lbD02 = new System.Windows.Forms.Label();
            this.laDO2 = new System.Windows.Forms.Label();
            this.gbDO1 = new System.Windows.Forms.GroupBox();
            this.cbWait1 = new System.Windows.Forms.CheckBox();
            this.btnExcute1 = new System.Windows.Forms.Button();
            this.lbWait1 = new System.Windows.Forms.Label();
            this.cbMode1 = new System.Windows.Forms.ComboBox();
            this.laDlyDO1 = new System.Windows.Forms.Label();
            this.labelDO1 = new System.Windows.Forms.Label();
            this.txtWaitTime1 = new System.Windows.Forms.TextBox();
            this.laDO1 = new System.Windows.Forms.Label();
            this.tbTimerDO1 = new System.Windows.Forms.TextBox();
            this.cbTimerDO1 = new System.Windows.Forms.CheckBox();
            this.lbD01 = new System.Windows.Forms.Label();
            this.lbSec1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbDI16 = new System.Windows.Forms.Label();
            this.lbSixTeen = new System.Windows.Forms.Label();
            this.lbDI15 = new System.Windows.Forms.Label();
            this.lbFifthTeen = new System.Windows.Forms.Label();
            this.lbDI14 = new System.Windows.Forms.Label();
            this.lbFourTeen = new System.Windows.Forms.Label();
            this.lbDI13 = new System.Windows.Forms.Label();
            this.lbThirTeen = new System.Windows.Forms.Label();
            this.lbDI12 = new System.Windows.Forms.Label();
            this.lbTwelve = new System.Windows.Forms.Label();
            this.lbDI11 = new System.Windows.Forms.Label();
            this.lbElevent = new System.Windows.Forms.Label();
            this.lbDI10 = new System.Windows.Forms.Label();
            this.lbTen = new System.Windows.Forms.Label();
            this.lbDI9 = new System.Windows.Forms.Label();
            this.lbNine = new System.Windows.Forms.Label();
            this.lbDI8 = new System.Windows.Forms.Label();
            this.lbEight = new System.Windows.Forms.Label();
            this.lbDI7 = new System.Windows.Forms.Label();
            this.lbServen = new System.Windows.Forms.Label();
            this.lbDI6 = new System.Windows.Forms.Label();
            this.lbSix = new System.Windows.Forms.Label();
            this.lbDI5 = new System.Windows.Forms.Label();
            this.lbFive = new System.Windows.Forms.Label();
            this.lbDI4 = new System.Windows.Forms.Label();
            this.lbFour = new System.Windows.Forms.Label();
            this.lbDI3 = new System.Windows.Forms.Label();
            this.lbThree = new System.Windows.Forms.Label();
            this.lbDI2 = new System.Windows.Forms.Label();
            this.lbTwo = new System.Windows.Forms.Label();
            this.lbDI1 = new System.Windows.Forms.Label();
            this.lbOne = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.NetConfigMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeviceManaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.languageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chineseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Model = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.LocalIP = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.LocalPort = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.currLinkNum = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.DateTimeWeek = new System.Windows.Forms.ToolStripLabel();
            this.cMS1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbDO15.SuspendLayout();
            this.gbDO16.SuspendLayout();
            this.gbDO14.SuspendLayout();
            this.gbDO13.SuspendLayout();
            this.gbDO12.SuspendLayout();
            this.gbDO11.SuspendLayout();
            this.gbDO10.SuspendLayout();
            this.gbDO9.SuspendLayout();
            this.gbDO8.SuspendLayout();
            this.gbDO7.SuspendLayout();
            this.gbDO6.SuspendLayout();
            this.gbDO5.SuspendLayout();
            this.gbDO4.SuspendLayout();
            this.gbDO3.SuspendLayout();
            this.gbDO2.SuspendLayout();
            this.gbDO1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cMS1
            // 
            this.cMS1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.保存显示ToolStripMenuItem,
            this.清除显示ToolStripMenuItem});
            this.cMS1.Name = "cMS1";
            this.cMS1.Size = new System.Drawing.Size(125, 48);
            // 
            // 保存显示ToolStripMenuItem
            // 
            this.保存显示ToolStripMenuItem.Name = "保存显示ToolStripMenuItem";
            this.保存显示ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.保存显示ToolStripMenuItem.Text = "保存显示";
            // 
            // 清除显示ToolStripMenuItem
            // 
            this.清除显示ToolStripMenuItem.Name = "清除显示ToolStripMenuItem";
            this.清除显示ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.清除显示ToolStripMenuItem.Text = "清除显示";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.gbDO15);
            this.groupBox2.Controls.Add(this.gbDO16);
            this.groupBox2.Controls.Add(this.gbDO14);
            this.groupBox2.Controls.Add(this.gbDO13);
            this.groupBox2.Controls.Add(this.gbDO12);
            this.groupBox2.Controls.Add(this.gbDO11);
            this.groupBox2.Controls.Add(this.gbDO10);
            this.groupBox2.Controls.Add(this.gbDO9);
            this.groupBox2.Controls.Add(this.gbDO8);
            this.groupBox2.Controls.Add(this.gbDO7);
            this.groupBox2.Controls.Add(this.gbDO6);
            this.groupBox2.Controls.Add(this.gbDO5);
            this.groupBox2.Controls.Add(this.gbDO4);
            this.groupBox2.Controls.Add(this.gbDO3);
            this.groupBox2.Controls.Add(this.gbDO2);
            this.groupBox2.Controls.Add(this.gbDO1);
            this.groupBox2.Location = new System.Drawing.Point(2, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(652, 568);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(259, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 29);
            this.label1.TabIndex = 86;
            this.label1.Text = "输出(OUT)";
            // 
            // gbDO15
            // 
            this.gbDO15.Controls.Add(this.cbWait15);
            this.gbDO15.Controls.Add(this.btnExcute15);
            this.gbDO15.Controls.Add(this.lbWait15);
            this.gbDO15.Controls.Add(this.cbMode15);
            this.gbDO15.Controls.Add(this.laDlyDO15);
            this.gbDO15.Controls.Add(this.labelDO15);
            this.gbDO15.Controls.Add(this.laDO15);
            this.gbDO15.Controls.Add(this.tbTimerDO15);
            this.gbDO15.Controls.Add(this.cbTimerDO15);
            this.gbDO15.Controls.Add(this.lbD015);
            this.gbDO15.Controls.Add(this.txtWaitTime15);
            this.gbDO15.Controls.Add(this.lbSec15);
            this.gbDO15.Location = new System.Drawing.Point(328, 433);
            this.gbDO15.Name = "gbDO15";
            this.gbDO15.Size = new System.Drawing.Size(158, 127);
            this.gbDO15.TabIndex = 84;
            this.gbDO15.TabStop = false;
            this.gbDO15.Text = "15";
            // 
            // cbWait15
            // 
            this.cbWait15.AutoSize = true;
            this.cbWait15.Location = new System.Drawing.Point(5, 107);
            this.cbWait15.Name = "cbWait15";
            this.cbWait15.Size = new System.Drawing.Size(15, 14);
            this.cbWait15.TabIndex = 80;
            this.cbWait15.UseVisualStyleBackColor = true;
            // 
            // btnExcute15
            // 
            this.btnExcute15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute15.Location = new System.Drawing.Point(74, 43);
            this.btnExcute15.Name = "btnExcute15";
            this.btnExcute15.Size = new System.Drawing.Size(79, 27);
            this.btnExcute15.TabIndex = 78;
            this.btnExcute15.Text = "执行";
            this.btnExcute15.UseVisualStyleBackColor = true;
            this.btnExcute15.Click += new System.EventHandler(this.btnExcute15_Click);
            // 
            // lbWait15
            // 
            this.lbWait15.AutoSize = true;
            this.lbWait15.Location = new System.Drawing.Point(26, 109);
            this.lbWait15.Name = "lbWait15";
            this.lbWait15.Size = new System.Drawing.Size(35, 14);
            this.lbWait15.TabIndex = 79;
            this.lbWait15.Text = "等待";
            // 
            // cbMode15
            // 
            this.cbMode15.FormattingEnabled = true;
            this.cbMode15.Location = new System.Drawing.Point(74, 15);
            this.cbMode15.Name = "cbMode15";
            this.cbMode15.Size = new System.Drawing.Size(79, 22);
            this.cbMode15.TabIndex = 76;
            this.cbMode15.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO15
            // 
            this.laDlyDO15.AutoSize = true;
            this.laDlyDO15.Location = new System.Drawing.Point(29, 49);
            this.laDlyDO15.Name = "laDlyDO15";
            this.laDlyDO15.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO15.TabIndex = 102;
            this.laDlyDO15.Text = "DO15";
            // 
            // labelDO15
            // 
            this.labelDO15.AutoSize = true;
            this.labelDO15.Location = new System.Drawing.Point(27, 79);
            this.labelDO15.Name = "labelDO15";
            this.labelDO15.Size = new System.Drawing.Size(35, 14);
            this.labelDO15.TabIndex = 101;
            this.labelDO15.Text = "延时";
            // 
            // laDO15
            // 
            this.laDO15.AutoSize = true;
            this.laDO15.Location = new System.Drawing.Point(129, 79);
            this.laDO15.Name = "laDO15";
            this.laDO15.Size = new System.Drawing.Size(21, 14);
            this.laDO15.TabIndex = 99;
            this.laDO15.Text = "秒";
            this.laDO15.Visible = false;
            // 
            // tbTimerDO15
            // 
            this.tbTimerDO15.Location = new System.Drawing.Point(74, 75);
            this.tbTimerDO15.Name = "tbTimerDO15";
            this.tbTimerDO15.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO15.TabIndex = 99;
            this.tbTimerDO15.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO15
            // 
            this.cbTimerDO15.AutoSize = true;
            this.cbTimerDO15.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO15.Name = "cbTimerDO15";
            this.cbTimerDO15.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO15.TabIndex = 98;
            this.cbTimerDO15.UseVisualStyleBackColor = true;
            // 
            // lbD015
            // 
            this.lbD015.AutoSize = true;
            this.lbD015.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD015.ForeColor = System.Drawing.Color.LightGray;
            this.lbD015.Location = new System.Drawing.Point(19, 15);
            this.lbD015.Name = "lbD015";
            this.lbD015.Size = new System.Drawing.Size(39, 27);
            this.lbD015.TabIndex = 61;
            this.lbD015.Text = "●";
            // 
            // txtWaitTime15
            // 
            this.txtWaitTime15.Location = new System.Drawing.Point(74, 103);
            this.txtWaitTime15.Name = "txtWaitTime15";
            this.txtWaitTime15.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime15.TabIndex = 77;
            this.txtWaitTime15.Visible = false;
            this.txtWaitTime15.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbSec15
            // 
            this.lbSec15.AutoSize = true;
            this.lbSec15.Location = new System.Drawing.Point(129, 106);
            this.lbSec15.Name = "lbSec15";
            this.lbSec15.Size = new System.Drawing.Size(21, 14);
            this.lbSec15.TabIndex = 72;
            this.lbSec15.Text = "秒";
            this.lbSec15.Visible = false;
            // 
            // gbDO16
            // 
            this.gbDO16.Controls.Add(this.cbWait16);
            this.gbDO16.Controls.Add(this.btnExcute16);
            this.gbDO16.Controls.Add(this.lbWait16);
            this.gbDO16.Controls.Add(this.cbMode16);
            this.gbDO16.Controls.Add(this.laDlyDO16);
            this.gbDO16.Controls.Add(this.labelDO16);
            this.gbDO16.Controls.Add(this.laDO16);
            this.gbDO16.Controls.Add(this.tbTimerDO16);
            this.gbDO16.Controls.Add(this.cbTimerDO16);
            this.gbDO16.Controls.Add(this.lbD016);
            this.gbDO16.Controls.Add(this.lbSec16);
            this.gbDO16.Controls.Add(this.txtWaitTime16);
            this.gbDO16.Location = new System.Drawing.Point(487, 433);
            this.gbDO16.Name = "gbDO16";
            this.gbDO16.Size = new System.Drawing.Size(160, 127);
            this.gbDO16.TabIndex = 85;
            this.gbDO16.TabStop = false;
            this.gbDO16.Text = "16";
            // 
            // cbWait16
            // 
            this.cbWait16.AutoSize = true;
            this.cbWait16.Location = new System.Drawing.Point(5, 107);
            this.cbWait16.Name = "cbWait16";
            this.cbWait16.Size = new System.Drawing.Size(15, 14);
            this.cbWait16.TabIndex = 80;
            this.cbWait16.UseVisualStyleBackColor = true;
            // 
            // btnExcute16
            // 
            this.btnExcute16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute16.Location = new System.Drawing.Point(75, 43);
            this.btnExcute16.Name = "btnExcute16";
            this.btnExcute16.Size = new System.Drawing.Size(79, 27);
            this.btnExcute16.TabIndex = 78;
            this.btnExcute16.Text = "执行";
            this.btnExcute16.UseVisualStyleBackColor = true;
            this.btnExcute16.Click += new System.EventHandler(this.btnExcute16_Click);
            // 
            // lbWait16
            // 
            this.lbWait16.AutoSize = true;
            this.lbWait16.Location = new System.Drawing.Point(26, 109);
            this.lbWait16.Name = "lbWait16";
            this.lbWait16.Size = new System.Drawing.Size(35, 14);
            this.lbWait16.TabIndex = 79;
            this.lbWait16.Text = "等待";
            // 
            // cbMode16
            // 
            this.cbMode16.FormattingEnabled = true;
            this.cbMode16.Location = new System.Drawing.Point(75, 15);
            this.cbMode16.Name = "cbMode16";
            this.cbMode16.Size = new System.Drawing.Size(79, 22);
            this.cbMode16.TabIndex = 76;
            this.cbMode16.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO16
            // 
            this.laDlyDO16.AutoSize = true;
            this.laDlyDO16.Location = new System.Drawing.Point(22, 49);
            this.laDlyDO16.Name = "laDlyDO16";
            this.laDlyDO16.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO16.TabIndex = 103;
            this.laDlyDO16.Text = "DO16";
            // 
            // labelDO16
            // 
            this.labelDO16.AutoSize = true;
            this.labelDO16.Location = new System.Drawing.Point(27, 79);
            this.labelDO16.Name = "labelDO16";
            this.labelDO16.Size = new System.Drawing.Size(35, 14);
            this.labelDO16.TabIndex = 102;
            this.labelDO16.Text = "延时";
            // 
            // laDO16
            // 
            this.laDO16.AutoSize = true;
            this.laDO16.Location = new System.Drawing.Point(125, 78);
            this.laDO16.Name = "laDO16";
            this.laDO16.Size = new System.Drawing.Size(21, 14);
            this.laDO16.TabIndex = 100;
            this.laDO16.Text = "秒";
            this.laDO16.Visible = false;
            // 
            // tbTimerDO16
            // 
            this.tbTimerDO16.Location = new System.Drawing.Point(75, 74);
            this.tbTimerDO16.Name = "tbTimerDO16";
            this.tbTimerDO16.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO16.TabIndex = 100;
            this.tbTimerDO16.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO16
            // 
            this.cbTimerDO16.AutoSize = true;
            this.cbTimerDO16.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO16.Name = "cbTimerDO16";
            this.cbTimerDO16.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO16.TabIndex = 99;
            this.cbTimerDO16.UseVisualStyleBackColor = true;
            // 
            // lbD016
            // 
            this.lbD016.AutoSize = true;
            this.lbD016.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD016.ForeColor = System.Drawing.Color.LightGray;
            this.lbD016.Location = new System.Drawing.Point(22, 15);
            this.lbD016.Name = "lbD016";
            this.lbD016.Size = new System.Drawing.Size(39, 27);
            this.lbD016.TabIndex = 63;
            this.lbD016.Text = "●";
            // 
            // lbSec16
            // 
            this.lbSec16.AutoSize = true;
            this.lbSec16.Location = new System.Drawing.Point(125, 106);
            this.lbSec16.Name = "lbSec16";
            this.lbSec16.Size = new System.Drawing.Size(21, 14);
            this.lbSec16.TabIndex = 72;
            this.lbSec16.Text = "秒";
            this.lbSec16.Visible = false;
            // 
            // txtWaitTime16
            // 
            this.txtWaitTime16.Location = new System.Drawing.Point(75, 103);
            this.txtWaitTime16.Name = "txtWaitTime16";
            this.txtWaitTime16.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime16.TabIndex = 77;
            this.txtWaitTime16.Visible = false;
            this.txtWaitTime16.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // gbDO14
            // 
            this.gbDO14.Controls.Add(this.cbWait14);
            this.gbDO14.Controls.Add(this.btnExcute14);
            this.gbDO14.Controls.Add(this.lbWait14);
            this.gbDO14.Controls.Add(this.cbMode14);
            this.gbDO14.Controls.Add(this.laDlyDO14);
            this.gbDO14.Controls.Add(this.labelDO14);
            this.gbDO14.Controls.Add(this.laDO14);
            this.gbDO14.Controls.Add(this.tbTimerDO14);
            this.gbDO14.Controls.Add(this.cbTimerDO14);
            this.gbDO14.Controls.Add(this.txtWaitTime14);
            this.gbDO14.Controls.Add(this.lbD014);
            this.gbDO14.Controls.Add(this.lbSec14);
            this.gbDO14.Location = new System.Drawing.Point(167, 433);
            this.gbDO14.Name = "gbDO14";
            this.gbDO14.Size = new System.Drawing.Size(160, 127);
            this.gbDO14.TabIndex = 83;
            this.gbDO14.TabStop = false;
            this.gbDO14.Text = "14";
            // 
            // cbWait14
            // 
            this.cbWait14.AutoSize = true;
            this.cbWait14.Location = new System.Drawing.Point(5, 107);
            this.cbWait14.Name = "cbWait14";
            this.cbWait14.Size = new System.Drawing.Size(15, 14);
            this.cbWait14.TabIndex = 80;
            this.cbWait14.UseVisualStyleBackColor = true;
            // 
            // btnExcute14
            // 
            this.btnExcute14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute14.Location = new System.Drawing.Point(76, 43);
            this.btnExcute14.Name = "btnExcute14";
            this.btnExcute14.Size = new System.Drawing.Size(79, 27);
            this.btnExcute14.TabIndex = 78;
            this.btnExcute14.Text = "执行";
            this.btnExcute14.UseVisualStyleBackColor = true;
            this.btnExcute14.Click += new System.EventHandler(this.btnExcute14_Click);
            // 
            // lbWait14
            // 
            this.lbWait14.AutoSize = true;
            this.lbWait14.Location = new System.Drawing.Point(26, 109);
            this.lbWait14.Name = "lbWait14";
            this.lbWait14.Size = new System.Drawing.Size(35, 14);
            this.lbWait14.TabIndex = 79;
            this.lbWait14.Text = "等待";
            // 
            // cbMode14
            // 
            this.cbMode14.FormattingEnabled = true;
            this.cbMode14.Location = new System.Drawing.Point(76, 14);
            this.cbMode14.Name = "cbMode14";
            this.cbMode14.Size = new System.Drawing.Size(78, 22);
            this.cbMode14.TabIndex = 76;
            this.cbMode14.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO14
            // 
            this.laDlyDO14.AutoSize = true;
            this.laDlyDO14.Location = new System.Drawing.Point(26, 49);
            this.laDlyDO14.Name = "laDlyDO14";
            this.laDlyDO14.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO14.TabIndex = 100;
            this.laDlyDO14.Text = "DO14";
            // 
            // labelDO14
            // 
            this.labelDO14.AutoSize = true;
            this.labelDO14.Location = new System.Drawing.Point(27, 79);
            this.labelDO14.Name = "labelDO14";
            this.labelDO14.Size = new System.Drawing.Size(35, 14);
            this.labelDO14.TabIndex = 99;
            this.labelDO14.Text = "延时";
            // 
            // laDO14
            // 
            this.laDO14.AutoSize = true;
            this.laDO14.Location = new System.Drawing.Point(131, 80);
            this.laDO14.Name = "laDO14";
            this.laDO14.Size = new System.Drawing.Size(21, 14);
            this.laDO14.TabIndex = 98;
            this.laDO14.Text = "秒";
            this.laDO14.Visible = false;
            // 
            // tbTimerDO14
            // 
            this.tbTimerDO14.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO14.Name = "tbTimerDO14";
            this.tbTimerDO14.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO14.TabIndex = 98;
            this.tbTimerDO14.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO14
            // 
            this.cbTimerDO14.AutoSize = true;
            this.cbTimerDO14.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO14.Name = "cbTimerDO14";
            this.cbTimerDO14.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO14.TabIndex = 96;
            this.cbTimerDO14.UseVisualStyleBackColor = true;
            // 
            // txtWaitTime14
            // 
            this.txtWaitTime14.Location = new System.Drawing.Point(76, 103);
            this.txtWaitTime14.Name = "txtWaitTime14";
            this.txtWaitTime14.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime14.TabIndex = 77;
            this.txtWaitTime14.Visible = false;
            this.txtWaitTime14.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD014
            // 
            this.lbD014.AutoSize = true;
            this.lbD014.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD014.ForeColor = System.Drawing.Color.LightGray;
            this.lbD014.Location = new System.Drawing.Point(19, 15);
            this.lbD014.Name = "lbD014";
            this.lbD014.Size = new System.Drawing.Size(39, 27);
            this.lbD014.TabIndex = 59;
            this.lbD014.Text = "●";
            // 
            // lbSec14
            // 
            this.lbSec14.AutoSize = true;
            this.lbSec14.Location = new System.Drawing.Point(131, 106);
            this.lbSec14.Name = "lbSec14";
            this.lbSec14.Size = new System.Drawing.Size(21, 14);
            this.lbSec14.TabIndex = 72;
            this.lbSec14.Text = "秒";
            this.lbSec14.Visible = false;
            // 
            // gbDO13
            // 
            this.gbDO13.Controls.Add(this.cbWait13);
            this.gbDO13.Controls.Add(this.btnExcute13);
            this.gbDO13.Controls.Add(this.lbWait13);
            this.gbDO13.Controls.Add(this.cbMode13);
            this.gbDO13.Controls.Add(this.laDlyDO13);
            this.gbDO13.Controls.Add(this.labelDO13);
            this.gbDO13.Controls.Add(this.cbTimerDO13);
            this.gbDO13.Controls.Add(this.txtWaitTime13);
            this.gbDO13.Controls.Add(this.laDO13);
            this.gbDO13.Controls.Add(this.tbTimerDO13);
            this.gbDO13.Controls.Add(this.lbD013);
            this.gbDO13.Controls.Add(this.lbSec13);
            this.gbDO13.Location = new System.Drawing.Point(6, 433);
            this.gbDO13.Name = "gbDO13";
            this.gbDO13.Size = new System.Drawing.Size(160, 127);
            this.gbDO13.TabIndex = 82;
            this.gbDO13.TabStop = false;
            this.gbDO13.Text = "13";
            // 
            // cbWait13
            // 
            this.cbWait13.AutoSize = true;
            this.cbWait13.Location = new System.Drawing.Point(5, 107);
            this.cbWait13.Name = "cbWait13";
            this.cbWait13.Size = new System.Drawing.Size(15, 14);
            this.cbWait13.TabIndex = 80;
            this.cbWait13.UseVisualStyleBackColor = true;
            // 
            // btnExcute13
            // 
            this.btnExcute13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute13.Location = new System.Drawing.Point(76, 43);
            this.btnExcute13.Name = "btnExcute13";
            this.btnExcute13.Size = new System.Drawing.Size(79, 27);
            this.btnExcute13.TabIndex = 78;
            this.btnExcute13.Text = "执行";
            this.btnExcute13.UseVisualStyleBackColor = true;
            this.btnExcute13.Click += new System.EventHandler(this.btnExcute13_Click);
            // 
            // lbWait13
            // 
            this.lbWait13.AutoSize = true;
            this.lbWait13.Location = new System.Drawing.Point(26, 109);
            this.lbWait13.Name = "lbWait13";
            this.lbWait13.Size = new System.Drawing.Size(35, 14);
            this.lbWait13.TabIndex = 79;
            this.lbWait13.Text = "等待";
            // 
            // cbMode13
            // 
            this.cbMode13.FormattingEnabled = true;
            this.cbMode13.Location = new System.Drawing.Point(76, 15);
            this.cbMode13.Name = "cbMode13";
            this.cbMode13.Size = new System.Drawing.Size(79, 22);
            this.cbMode13.TabIndex = 76;
            this.cbMode13.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO13
            // 
            this.laDlyDO13.AutoSize = true;
            this.laDlyDO13.Location = new System.Drawing.Point(26, 49);
            this.laDlyDO13.Name = "laDlyDO13";
            this.laDlyDO13.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO13.TabIndex = 99;
            this.laDlyDO13.Text = "DO13";
            // 
            // labelDO13
            // 
            this.labelDO13.AutoSize = true;
            this.labelDO13.Location = new System.Drawing.Point(27, 79);
            this.labelDO13.Name = "labelDO13";
            this.labelDO13.Size = new System.Drawing.Size(35, 14);
            this.labelDO13.TabIndex = 98;
            this.labelDO13.Text = "延时";
            // 
            // cbTimerDO13
            // 
            this.cbTimerDO13.AutoSize = true;
            this.cbTimerDO13.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO13.Name = "cbTimerDO13";
            this.cbTimerDO13.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO13.TabIndex = 97;
            this.cbTimerDO13.UseVisualStyleBackColor = true;
            // 
            // txtWaitTime13
            // 
            this.txtWaitTime13.Location = new System.Drawing.Point(76, 103);
            this.txtWaitTime13.Name = "txtWaitTime13";
            this.txtWaitTime13.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime13.TabIndex = 77;
            this.txtWaitTime13.Visible = false;
            this.txtWaitTime13.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // laDO13
            // 
            this.laDO13.AutoSize = true;
            this.laDO13.Location = new System.Drawing.Point(126, 82);
            this.laDO13.Name = "laDO13";
            this.laDO13.Size = new System.Drawing.Size(21, 14);
            this.laDO13.TabIndex = 97;
            this.laDO13.Text = "秒";
            this.laDO13.Visible = false;
            // 
            // tbTimerDO13
            // 
            this.tbTimerDO13.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO13.Name = "tbTimerDO13";
            this.tbTimerDO13.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO13.TabIndex = 97;
            this.tbTimerDO13.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD013
            // 
            this.lbD013.AutoSize = true;
            this.lbD013.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD013.ForeColor = System.Drawing.Color.LightGray;
            this.lbD013.Location = new System.Drawing.Point(25, 15);
            this.lbD013.Name = "lbD013";
            this.lbD013.Size = new System.Drawing.Size(39, 27);
            this.lbD013.TabIndex = 57;
            this.lbD013.Text = "●";
            // 
            // lbSec13
            // 
            this.lbSec13.AutoSize = true;
            this.lbSec13.Location = new System.Drawing.Point(126, 106);
            this.lbSec13.Name = "lbSec13";
            this.lbSec13.Size = new System.Drawing.Size(21, 14);
            this.lbSec13.TabIndex = 72;
            this.lbSec13.Text = "秒";
            this.lbSec13.Visible = false;
            // 
            // gbDO12
            // 
            this.gbDO12.Controls.Add(this.cbWait12);
            this.gbDO12.Controls.Add(this.btnExcute12);
            this.gbDO12.Controls.Add(this.cbMode12);
            this.gbDO12.Controls.Add(this.laDlyDO12);
            this.gbDO12.Controls.Add(this.lbWait12);
            this.gbDO12.Controls.Add(this.labelDO12);
            this.gbDO12.Controls.Add(this.lbD012);
            this.gbDO12.Controls.Add(this.laDO12);
            this.gbDO12.Controls.Add(this.tbTimerDO12);
            this.gbDO12.Controls.Add(this.txtWaitTime12);
            this.gbDO12.Controls.Add(this.cbTimerDO12);
            this.gbDO12.Controls.Add(this.lbSec12);
            this.gbDO12.Location = new System.Drawing.Point(487, 304);
            this.gbDO12.Name = "gbDO12";
            this.gbDO12.Size = new System.Drawing.Size(160, 127);
            this.gbDO12.TabIndex = 81;
            this.gbDO12.TabStop = false;
            this.gbDO12.Text = "12";
            // 
            // cbWait12
            // 
            this.cbWait12.AutoSize = true;
            this.cbWait12.Location = new System.Drawing.Point(5, 104);
            this.cbWait12.Name = "cbWait12";
            this.cbWait12.Size = new System.Drawing.Size(15, 14);
            this.cbWait12.TabIndex = 80;
            this.cbWait12.UseVisualStyleBackColor = true;
            // 
            // btnExcute12
            // 
            this.btnExcute12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute12.Location = new System.Drawing.Point(75, 43);
            this.btnExcute12.Name = "btnExcute12";
            this.btnExcute12.Size = new System.Drawing.Size(79, 27);
            this.btnExcute12.TabIndex = 78;
            this.btnExcute12.Text = "执行";
            this.btnExcute12.UseVisualStyleBackColor = true;
            this.btnExcute12.Click += new System.EventHandler(this.btnExcute12_Click);
            // 
            // cbMode12
            // 
            this.cbMode12.FormattingEnabled = true;
            this.cbMode12.Location = new System.Drawing.Point(75, 15);
            this.cbMode12.Name = "cbMode12";
            this.cbMode12.Size = new System.Drawing.Size(79, 22);
            this.cbMode12.TabIndex = 76;
            this.cbMode12.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO12
            // 
            this.laDlyDO12.AutoSize = true;
            this.laDlyDO12.Location = new System.Drawing.Point(22, 52);
            this.laDlyDO12.Name = "laDlyDO12";
            this.laDlyDO12.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO12.TabIndex = 98;
            this.laDlyDO12.Text = "DO12";
            // 
            // lbWait12
            // 
            this.lbWait12.AutoSize = true;
            this.lbWait12.Location = new System.Drawing.Point(26, 106);
            this.lbWait12.Name = "lbWait12";
            this.lbWait12.Size = new System.Drawing.Size(35, 14);
            this.lbWait12.TabIndex = 79;
            this.lbWait12.Text = "等待";
            // 
            // labelDO12
            // 
            this.labelDO12.AutoSize = true;
            this.labelDO12.Location = new System.Drawing.Point(27, 79);
            this.labelDO12.Name = "labelDO12";
            this.labelDO12.Size = new System.Drawing.Size(35, 14);
            this.labelDO12.TabIndex = 97;
            this.labelDO12.Text = "延时";
            // 
            // lbD012
            // 
            this.lbD012.AutoSize = true;
            this.lbD012.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD012.ForeColor = System.Drawing.Color.LightGray;
            this.lbD012.Location = new System.Drawing.Point(22, 15);
            this.lbD012.Name = "lbD012";
            this.lbD012.Size = new System.Drawing.Size(39, 27);
            this.lbD012.TabIndex = 55;
            this.lbD012.Text = "●";
            // 
            // laDO12
            // 
            this.laDO12.AutoSize = true;
            this.laDO12.Location = new System.Drawing.Point(125, 77);
            this.laDO12.Name = "laDO12";
            this.laDO12.Size = new System.Drawing.Size(21, 14);
            this.laDO12.TabIndex = 96;
            this.laDO12.Text = "秒";
            this.laDO12.Visible = false;
            // 
            // tbTimerDO12
            // 
            this.tbTimerDO12.Location = new System.Drawing.Point(75, 75);
            this.tbTimerDO12.Name = "tbTimerDO12";
            this.tbTimerDO12.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO12.TabIndex = 96;
            this.tbTimerDO12.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // txtWaitTime12
            // 
            this.txtWaitTime12.Location = new System.Drawing.Point(75, 101);
            this.txtWaitTime12.Name = "txtWaitTime12";
            this.txtWaitTime12.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime12.TabIndex = 77;
            this.txtWaitTime12.Visible = false;
            this.txtWaitTime12.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO12
            // 
            this.cbTimerDO12.AutoSize = true;
            this.cbTimerDO12.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO12.Name = "cbTimerDO12";
            this.cbTimerDO12.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO12.TabIndex = 95;
            this.cbTimerDO12.UseVisualStyleBackColor = true;
            // 
            // lbSec12
            // 
            this.lbSec12.AutoSize = true;
            this.lbSec12.Location = new System.Drawing.Point(125, 100);
            this.lbSec12.Name = "lbSec12";
            this.lbSec12.Size = new System.Drawing.Size(21, 14);
            this.lbSec12.TabIndex = 72;
            this.lbSec12.Text = "秒";
            this.lbSec12.Visible = false;
            // 
            // gbDO11
            // 
            this.gbDO11.Controls.Add(this.cbWait11);
            this.gbDO11.Controls.Add(this.btnExcute11);
            this.gbDO11.Controls.Add(this.cbMode11);
            this.gbDO11.Controls.Add(this.lbWait11);
            this.gbDO11.Controls.Add(this.laDlyDO11);
            this.gbDO11.Controls.Add(this.labelDO11);
            this.gbDO11.Controls.Add(this.lbD011);
            this.gbDO11.Controls.Add(this.cbTimerDO11);
            this.gbDO11.Controls.Add(this.txtWaitTime11);
            this.gbDO11.Controls.Add(this.laDO11);
            this.gbDO11.Controls.Add(this.tbTimerDO11);
            this.gbDO11.Controls.Add(this.lbSec11);
            this.gbDO11.Location = new System.Drawing.Point(328, 304);
            this.gbDO11.Name = "gbDO11";
            this.gbDO11.Size = new System.Drawing.Size(158, 127);
            this.gbDO11.TabIndex = 80;
            this.gbDO11.TabStop = false;
            this.gbDO11.Text = "11";
            // 
            // cbWait11
            // 
            this.cbWait11.AutoSize = true;
            this.cbWait11.Location = new System.Drawing.Point(5, 104);
            this.cbWait11.Name = "cbWait11";
            this.cbWait11.Size = new System.Drawing.Size(15, 14);
            this.cbWait11.TabIndex = 80;
            this.cbWait11.UseVisualStyleBackColor = true;
            // 
            // btnExcute11
            // 
            this.btnExcute11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute11.Location = new System.Drawing.Point(74, 43);
            this.btnExcute11.Name = "btnExcute11";
            this.btnExcute11.Size = new System.Drawing.Size(79, 27);
            this.btnExcute11.TabIndex = 78;
            this.btnExcute11.Text = "执行";
            this.btnExcute11.UseVisualStyleBackColor = true;
            this.btnExcute11.Click += new System.EventHandler(this.btnExcute11_Click);
            // 
            // cbMode11
            // 
            this.cbMode11.FormattingEnabled = true;
            this.cbMode11.Location = new System.Drawing.Point(74, 15);
            this.cbMode11.Name = "cbMode11";
            this.cbMode11.Size = new System.Drawing.Size(79, 22);
            this.cbMode11.TabIndex = 76;
            this.cbMode11.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // lbWait11
            // 
            this.lbWait11.AutoSize = true;
            this.lbWait11.Location = new System.Drawing.Point(26, 106);
            this.lbWait11.Name = "lbWait11";
            this.lbWait11.Size = new System.Drawing.Size(35, 14);
            this.lbWait11.TabIndex = 79;
            this.lbWait11.Text = "等待";
            // 
            // laDlyDO11
            // 
            this.laDlyDO11.AutoSize = true;
            this.laDlyDO11.Location = new System.Drawing.Point(26, 52);
            this.laDlyDO11.Name = "laDlyDO11";
            this.laDlyDO11.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO11.TabIndex = 97;
            this.laDlyDO11.Text = "DO11";
            // 
            // labelDO11
            // 
            this.labelDO11.AutoSize = true;
            this.labelDO11.Location = new System.Drawing.Point(27, 79);
            this.labelDO11.Name = "labelDO11";
            this.labelDO11.Size = new System.Drawing.Size(35, 14);
            this.labelDO11.TabIndex = 96;
            this.labelDO11.Text = "延时";
            // 
            // lbD011
            // 
            this.lbD011.AutoSize = true;
            this.lbD011.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD011.ForeColor = System.Drawing.Color.LightGray;
            this.lbD011.Location = new System.Drawing.Point(19, 15);
            this.lbD011.Name = "lbD011";
            this.lbD011.Size = new System.Drawing.Size(39, 27);
            this.lbD011.TabIndex = 53;
            this.lbD011.Text = "●";
            // 
            // cbTimerDO11
            // 
            this.cbTimerDO11.AutoSize = true;
            this.cbTimerDO11.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO11.Name = "cbTimerDO11";
            this.cbTimerDO11.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO11.TabIndex = 94;
            this.cbTimerDO11.UseVisualStyleBackColor = true;
            // 
            // txtWaitTime11
            // 
            this.txtWaitTime11.Location = new System.Drawing.Point(74, 101);
            this.txtWaitTime11.Name = "txtWaitTime11";
            this.txtWaitTime11.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime11.TabIndex = 77;
            this.txtWaitTime11.Visible = false;
            this.txtWaitTime11.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // laDO11
            // 
            this.laDO11.AutoSize = true;
            this.laDO11.Location = new System.Drawing.Point(129, 82);
            this.laDO11.Name = "laDO11";
            this.laDO11.Size = new System.Drawing.Size(21, 14);
            this.laDO11.TabIndex = 95;
            this.laDO11.Text = "秒";
            this.laDO11.Visible = false;
            // 
            // tbTimerDO11
            // 
            this.tbTimerDO11.Location = new System.Drawing.Point(74, 75);
            this.tbTimerDO11.Name = "tbTimerDO11";
            this.tbTimerDO11.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO11.TabIndex = 95;
            this.tbTimerDO11.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbSec11
            // 
            this.lbSec11.AutoSize = true;
            this.lbSec11.Location = new System.Drawing.Point(129, 105);
            this.lbSec11.Name = "lbSec11";
            this.lbSec11.Size = new System.Drawing.Size(21, 14);
            this.lbSec11.TabIndex = 72;
            this.lbSec11.Text = "秒";
            this.lbSec11.Visible = false;
            // 
            // gbDO10
            // 
            this.gbDO10.Controls.Add(this.cbWait10);
            this.gbDO10.Controls.Add(this.btnExcute10);
            this.gbDO10.Controls.Add(this.lbWait10);
            this.gbDO10.Controls.Add(this.cbMode10);
            this.gbDO10.Controls.Add(this.laDlyDO10);
            this.gbDO10.Controls.Add(this.labelDO10);
            this.gbDO10.Controls.Add(this.tbTimerDO10);
            this.gbDO10.Controls.Add(this.txtWaitTime10);
            this.gbDO10.Controls.Add(this.lbD10);
            this.gbDO10.Controls.Add(this.cbTimerDO10);
            this.gbDO10.Controls.Add(this.laDO10);
            this.gbDO10.Controls.Add(this.lbSec10);
            this.gbDO10.Location = new System.Drawing.Point(167, 304);
            this.gbDO10.Name = "gbDO10";
            this.gbDO10.Size = new System.Drawing.Size(160, 127);
            this.gbDO10.TabIndex = 79;
            this.gbDO10.TabStop = false;
            this.gbDO10.Text = "10";
            // 
            // cbWait10
            // 
            this.cbWait10.AutoSize = true;
            this.cbWait10.Location = new System.Drawing.Point(5, 105);
            this.cbWait10.Name = "cbWait10";
            this.cbWait10.Size = new System.Drawing.Size(15, 14);
            this.cbWait10.TabIndex = 80;
            this.cbWait10.UseVisualStyleBackColor = true;
            // 
            // btnExcute10
            // 
            this.btnExcute10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute10.Location = new System.Drawing.Point(76, 43);
            this.btnExcute10.Name = "btnExcute10";
            this.btnExcute10.Size = new System.Drawing.Size(79, 27);
            this.btnExcute10.TabIndex = 78;
            this.btnExcute10.Text = "执行";
            this.btnExcute10.UseVisualStyleBackColor = true;
            this.btnExcute10.Click += new System.EventHandler(this.btnExcute10_Click);
            // 
            // lbWait10
            // 
            this.lbWait10.AutoSize = true;
            this.lbWait10.Location = new System.Drawing.Point(26, 107);
            this.lbWait10.Name = "lbWait10";
            this.lbWait10.Size = new System.Drawing.Size(35, 14);
            this.lbWait10.TabIndex = 79;
            this.lbWait10.Text = "等待";
            // 
            // cbMode10
            // 
            this.cbMode10.FormattingEnabled = true;
            this.cbMode10.Location = new System.Drawing.Point(76, 13);
            this.cbMode10.Name = "cbMode10";
            this.cbMode10.Size = new System.Drawing.Size(78, 22);
            this.cbMode10.TabIndex = 76;
            this.cbMode10.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO10
            // 
            this.laDlyDO10.AutoSize = true;
            this.laDlyDO10.Location = new System.Drawing.Point(26, 52);
            this.laDlyDO10.Name = "laDlyDO10";
            this.laDlyDO10.Size = new System.Drawing.Size(35, 14);
            this.laDlyDO10.TabIndex = 97;
            this.laDlyDO10.Text = "DO10";
            // 
            // labelDO10
            // 
            this.labelDO10.AutoSize = true;
            this.labelDO10.Location = new System.Drawing.Point(27, 79);
            this.labelDO10.Name = "labelDO10";
            this.labelDO10.Size = new System.Drawing.Size(35, 14);
            this.labelDO10.TabIndex = 96;
            this.labelDO10.Text = "延时";
            // 
            // tbTimerDO10
            // 
            this.tbTimerDO10.Location = new System.Drawing.Point(76, 75);
            this.tbTimerDO10.Name = "tbTimerDO10";
            this.tbTimerDO10.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO10.TabIndex = 95;
            this.tbTimerDO10.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // txtWaitTime10
            // 
            this.txtWaitTime10.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime10.Name = "txtWaitTime10";
            this.txtWaitTime10.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime10.TabIndex = 77;
            this.txtWaitTime10.Visible = false;
            this.txtWaitTime10.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD10
            // 
            this.lbD10.AutoSize = true;
            this.lbD10.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD10.ForeColor = System.Drawing.Color.LightGray;
            this.lbD10.Location = new System.Drawing.Point(19, 15);
            this.lbD10.Name = "lbD10";
            this.lbD10.Size = new System.Drawing.Size(39, 27);
            this.lbD10.TabIndex = 51;
            this.lbD10.Text = "●";
            // 
            // cbTimerDO10
            // 
            this.cbTimerDO10.AutoSize = true;
            this.cbTimerDO10.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO10.Name = "cbTimerDO10";
            this.cbTimerDO10.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO10.TabIndex = 93;
            this.cbTimerDO10.UseVisualStyleBackColor = true;
            // 
            // laDO10
            // 
            this.laDO10.AutoSize = true;
            this.laDO10.Location = new System.Drawing.Point(131, 82);
            this.laDO10.Name = "laDO10";
            this.laDO10.Size = new System.Drawing.Size(21, 14);
            this.laDO10.TabIndex = 94;
            this.laDO10.Text = "秒";
            this.laDO10.Visible = false;
            // 
            // lbSec10
            // 
            this.lbSec10.AutoSize = true;
            this.lbSec10.Location = new System.Drawing.Point(131, 106);
            this.lbSec10.Name = "lbSec10";
            this.lbSec10.Size = new System.Drawing.Size(21, 14);
            this.lbSec10.TabIndex = 72;
            this.lbSec10.Text = "秒";
            this.lbSec10.Visible = false;
            // 
            // gbDO9
            // 
            this.gbDO9.Controls.Add(this.cbWait9);
            this.gbDO9.Controls.Add(this.btnExcute9);
            this.gbDO9.Controls.Add(this.lbWait9);
            this.gbDO9.Controls.Add(this.cbMode9);
            this.gbDO9.Controls.Add(this.laDlyDO9);
            this.gbDO9.Controls.Add(this.labelDO9);
            this.gbDO9.Controls.Add(this.tbTimerDO9);
            this.gbDO9.Controls.Add(this.lbD09);
            this.gbDO9.Controls.Add(this.txtWaitTime9);
            this.gbDO9.Controls.Add(this.cbTimerDO9);
            this.gbDO9.Controls.Add(this.laDO9);
            this.gbDO9.Controls.Add(this.lbSec9);
            this.gbDO9.Location = new System.Drawing.Point(6, 304);
            this.gbDO9.Name = "gbDO9";
            this.gbDO9.Size = new System.Drawing.Size(160, 127);
            this.gbDO9.TabIndex = 78;
            this.gbDO9.TabStop = false;
            this.gbDO9.Text = "9";
            // 
            // cbWait9
            // 
            this.cbWait9.AutoSize = true;
            this.cbWait9.Location = new System.Drawing.Point(5, 104);
            this.cbWait9.Name = "cbWait9";
            this.cbWait9.Size = new System.Drawing.Size(15, 14);
            this.cbWait9.TabIndex = 80;
            this.cbWait9.UseVisualStyleBackColor = true;
            // 
            // btnExcute9
            // 
            this.btnExcute9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute9.Location = new System.Drawing.Point(76, 43);
            this.btnExcute9.Name = "btnExcute9";
            this.btnExcute9.Size = new System.Drawing.Size(79, 27);
            this.btnExcute9.TabIndex = 78;
            this.btnExcute9.Text = "执行";
            this.btnExcute9.UseVisualStyleBackColor = true;
            this.btnExcute9.Click += new System.EventHandler(this.btnExcute9_Click);
            // 
            // lbWait9
            // 
            this.lbWait9.AutoSize = true;
            this.lbWait9.Location = new System.Drawing.Point(26, 106);
            this.lbWait9.Name = "lbWait9";
            this.lbWait9.Size = new System.Drawing.Size(35, 14);
            this.lbWait9.TabIndex = 79;
            this.lbWait9.Text = "等待";
            // 
            // cbMode9
            // 
            this.cbMode9.FormattingEnabled = true;
            this.cbMode9.Location = new System.Drawing.Point(76, 15);
            this.cbMode9.Name = "cbMode9";
            this.cbMode9.Size = new System.Drawing.Size(79, 22);
            this.cbMode9.TabIndex = 76;
            this.cbMode9.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO9
            // 
            this.laDlyDO9.AutoSize = true;
            this.laDlyDO9.Location = new System.Drawing.Point(27, 52);
            this.laDlyDO9.Name = "laDlyDO9";
            this.laDlyDO9.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO9.TabIndex = 96;
            this.laDlyDO9.Text = "D09";
            // 
            // labelDO9
            // 
            this.labelDO9.AutoSize = true;
            this.labelDO9.Location = new System.Drawing.Point(27, 79);
            this.labelDO9.Name = "labelDO9";
            this.labelDO9.Size = new System.Drawing.Size(35, 14);
            this.labelDO9.TabIndex = 95;
            this.labelDO9.Text = "延时";
            // 
            // tbTimerDO9
            // 
            this.tbTimerDO9.Location = new System.Drawing.Point(76, 75);
            this.tbTimerDO9.Name = "tbTimerDO9";
            this.tbTimerDO9.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO9.TabIndex = 94;
            this.tbTimerDO9.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD09
            // 
            this.lbD09.AutoSize = true;
            this.lbD09.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD09.ForeColor = System.Drawing.Color.LightGray;
            this.lbD09.Location = new System.Drawing.Point(25, 15);
            this.lbD09.Name = "lbD09";
            this.lbD09.Size = new System.Drawing.Size(39, 27);
            this.lbD09.TabIndex = 49;
            this.lbD09.Text = "●";
            // 
            // txtWaitTime9
            // 
            this.txtWaitTime9.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime9.Name = "txtWaitTime9";
            this.txtWaitTime9.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime9.TabIndex = 77;
            this.txtWaitTime9.Visible = false;
            this.txtWaitTime9.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO9
            // 
            this.cbTimerDO9.AutoSize = true;
            this.cbTimerDO9.Location = new System.Drawing.Point(5, 80);
            this.cbTimerDO9.Name = "cbTimerDO9";
            this.cbTimerDO9.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO9.TabIndex = 92;
            this.cbTimerDO9.UseVisualStyleBackColor = true;
            // 
            // laDO9
            // 
            this.laDO9.AutoSize = true;
            this.laDO9.Location = new System.Drawing.Point(126, 79);
            this.laDO9.Name = "laDO9";
            this.laDO9.Size = new System.Drawing.Size(21, 14);
            this.laDO9.TabIndex = 93;
            this.laDO9.Text = "秒";
            this.laDO9.Visible = false;
            // 
            // lbSec9
            // 
            this.lbSec9.AutoSize = true;
            this.lbSec9.Location = new System.Drawing.Point(126, 104);
            this.lbSec9.Name = "lbSec9";
            this.lbSec9.Size = new System.Drawing.Size(21, 14);
            this.lbSec9.TabIndex = 72;
            this.lbSec9.Text = "秒";
            this.lbSec9.Visible = false;
            // 
            // gbDO8
            // 
            this.gbDO8.Controls.Add(this.cbWait8);
            this.gbDO8.Controls.Add(this.btnExcute8);
            this.gbDO8.Controls.Add(this.cbMode8);
            this.gbDO8.Controls.Add(this.lbWait8);
            this.gbDO8.Controls.Add(this.laDlyDO8);
            this.gbDO8.Controls.Add(this.labelDO8);
            this.gbDO8.Controls.Add(this.txtWaitTime8);
            this.gbDO8.Controls.Add(this.tbTimerDO8);
            this.gbDO8.Controls.Add(this.lbD08);
            this.gbDO8.Controls.Add(this.cbTimerDO8);
            this.gbDO8.Controls.Add(this.laDO8);
            this.gbDO8.Controls.Add(this.lbSec8);
            this.gbDO8.Location = new System.Drawing.Point(487, 173);
            this.gbDO8.Name = "gbDO8";
            this.gbDO8.Size = new System.Drawing.Size(160, 127);
            this.gbDO8.TabIndex = 77;
            this.gbDO8.TabStop = false;
            this.gbDO8.Text = "8";
            // 
            // cbWait8
            // 
            this.cbWait8.AutoSize = true;
            this.cbWait8.Location = new System.Drawing.Point(5, 105);
            this.cbWait8.Name = "cbWait8";
            this.cbWait8.Size = new System.Drawing.Size(15, 14);
            this.cbWait8.TabIndex = 80;
            this.cbWait8.UseVisualStyleBackColor = true;
            // 
            // btnExcute8
            // 
            this.btnExcute8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute8.Location = new System.Drawing.Point(75, 43);
            this.btnExcute8.Name = "btnExcute8";
            this.btnExcute8.Size = new System.Drawing.Size(79, 27);
            this.btnExcute8.TabIndex = 78;
            this.btnExcute8.Text = "执行";
            this.btnExcute8.UseVisualStyleBackColor = true;
            this.btnExcute8.Click += new System.EventHandler(this.btnExcute8_Click);
            // 
            // cbMode8
            // 
            this.cbMode8.FormattingEnabled = true;
            this.cbMode8.Location = new System.Drawing.Point(75, 15);
            this.cbMode8.Name = "cbMode8";
            this.cbMode8.Size = new System.Drawing.Size(79, 22);
            this.cbMode8.TabIndex = 76;
            this.cbMode8.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // lbWait8
            // 
            this.lbWait8.AutoSize = true;
            this.lbWait8.Location = new System.Drawing.Point(26, 106);
            this.lbWait8.Name = "lbWait8";
            this.lbWait8.Size = new System.Drawing.Size(35, 14);
            this.lbWait8.TabIndex = 79;
            this.lbWait8.Text = "等待";
            // 
            // laDlyDO8
            // 
            this.laDlyDO8.AutoSize = true;
            this.laDlyDO8.Location = new System.Drawing.Point(29, 49);
            this.laDlyDO8.Name = "laDlyDO8";
            this.laDlyDO8.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO8.TabIndex = 95;
            this.laDlyDO8.Text = "D08";
            // 
            // labelDO8
            // 
            this.labelDO8.AutoSize = true;
            this.labelDO8.Location = new System.Drawing.Point(27, 79);
            this.labelDO8.Name = "labelDO8";
            this.labelDO8.Size = new System.Drawing.Size(35, 14);
            this.labelDO8.TabIndex = 94;
            this.labelDO8.Text = "延时";
            // 
            // txtWaitTime8
            // 
            this.txtWaitTime8.Location = new System.Drawing.Point(75, 101);
            this.txtWaitTime8.Name = "txtWaitTime8";
            this.txtWaitTime8.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime8.TabIndex = 77;
            this.txtWaitTime8.Visible = false;
            this.txtWaitTime8.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // tbTimerDO8
            // 
            this.tbTimerDO8.Location = new System.Drawing.Point(75, 76);
            this.tbTimerDO8.Name = "tbTimerDO8";
            this.tbTimerDO8.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO8.TabIndex = 93;
            this.tbTimerDO8.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD08
            // 
            this.lbD08.AutoSize = true;
            this.lbD08.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD08.ForeColor = System.Drawing.Color.LightGray;
            this.lbD08.Location = new System.Drawing.Point(22, 15);
            this.lbD08.Name = "lbD08";
            this.lbD08.Size = new System.Drawing.Size(39, 27);
            this.lbD08.TabIndex = 47;
            this.lbD08.Text = "●";
            // 
            // cbTimerDO8
            // 
            this.cbTimerDO8.AutoSize = true;
            this.cbTimerDO8.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO8.Name = "cbTimerDO8";
            this.cbTimerDO8.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO8.TabIndex = 91;
            this.cbTimerDO8.UseVisualStyleBackColor = true;
            // 
            // laDO8
            // 
            this.laDO8.AutoSize = true;
            this.laDO8.Location = new System.Drawing.Point(125, 80);
            this.laDO8.Name = "laDO8";
            this.laDO8.Size = new System.Drawing.Size(21, 14);
            this.laDO8.TabIndex = 92;
            this.laDO8.Text = "秒";
            this.laDO8.Visible = false;
            // 
            // lbSec8
            // 
            this.lbSec8.AutoSize = true;
            this.lbSec8.Location = new System.Drawing.Point(125, 104);
            this.lbSec8.Name = "lbSec8";
            this.lbSec8.Size = new System.Drawing.Size(21, 14);
            this.lbSec8.TabIndex = 72;
            this.lbSec8.Text = "秒";
            this.lbSec8.Visible = false;
            // 
            // gbDO7
            // 
            this.gbDO7.Controls.Add(this.cbWait7);
            this.gbDO7.Controls.Add(this.btnExcute7);
            this.gbDO7.Controls.Add(this.lbWait7);
            this.gbDO7.Controls.Add(this.cbMode7);
            this.gbDO7.Controls.Add(this.laDlyDO7);
            this.gbDO7.Controls.Add(this.txtWaitTime7);
            this.gbDO7.Controls.Add(this.labelDO7);
            this.gbDO7.Controls.Add(this.tbTimerDO7);
            this.gbDO7.Controls.Add(this.lbD07);
            this.gbDO7.Controls.Add(this.cbTimerDO7);
            this.gbDO7.Controls.Add(this.laDO7);
            this.gbDO7.Controls.Add(this.lbSec7);
            this.gbDO7.Location = new System.Drawing.Point(328, 173);
            this.gbDO7.Name = "gbDO7";
            this.gbDO7.Size = new System.Drawing.Size(158, 127);
            this.gbDO7.TabIndex = 76;
            this.gbDO7.TabStop = false;
            this.gbDO7.Text = "7";
            // 
            // cbWait7
            // 
            this.cbWait7.AutoSize = true;
            this.cbWait7.Location = new System.Drawing.Point(5, 104);
            this.cbWait7.Name = "cbWait7";
            this.cbWait7.Size = new System.Drawing.Size(15, 14);
            this.cbWait7.TabIndex = 80;
            this.cbWait7.UseVisualStyleBackColor = true;
            // 
            // btnExcute7
            // 
            this.btnExcute7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute7.Location = new System.Drawing.Point(74, 43);
            this.btnExcute7.Name = "btnExcute7";
            this.btnExcute7.Size = new System.Drawing.Size(79, 27);
            this.btnExcute7.TabIndex = 78;
            this.btnExcute7.Text = "执行";
            this.btnExcute7.UseVisualStyleBackColor = true;
            this.btnExcute7.Click += new System.EventHandler(this.btnExcute7_Click);
            // 
            // lbWait7
            // 
            this.lbWait7.AutoSize = true;
            this.lbWait7.Location = new System.Drawing.Point(26, 105);
            this.lbWait7.Name = "lbWait7";
            this.lbWait7.Size = new System.Drawing.Size(35, 14);
            this.lbWait7.TabIndex = 79;
            this.lbWait7.Text = "等待";
            // 
            // cbMode7
            // 
            this.cbMode7.FormattingEnabled = true;
            this.cbMode7.Location = new System.Drawing.Point(74, 15);
            this.cbMode7.Name = "cbMode7";
            this.cbMode7.Size = new System.Drawing.Size(79, 22);
            this.cbMode7.TabIndex = 76;
            this.cbMode7.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO7
            // 
            this.laDlyDO7.AutoSize = true;
            this.laDlyDO7.Location = new System.Drawing.Point(30, 49);
            this.laDlyDO7.Name = "laDlyDO7";
            this.laDlyDO7.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO7.TabIndex = 94;
            this.laDlyDO7.Text = "D07";
            // 
            // txtWaitTime7
            // 
            this.txtWaitTime7.Location = new System.Drawing.Point(74, 101);
            this.txtWaitTime7.Name = "txtWaitTime7";
            this.txtWaitTime7.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime7.TabIndex = 77;
            this.txtWaitTime7.Visible = false;
            this.txtWaitTime7.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // labelDO7
            // 
            this.labelDO7.AutoSize = true;
            this.labelDO7.Location = new System.Drawing.Point(27, 79);
            this.labelDO7.Name = "labelDO7";
            this.labelDO7.Size = new System.Drawing.Size(35, 14);
            this.labelDO7.TabIndex = 93;
            this.labelDO7.Text = "延时";
            // 
            // tbTimerDO7
            // 
            this.tbTimerDO7.Location = new System.Drawing.Point(74, 76);
            this.tbTimerDO7.Name = "tbTimerDO7";
            this.tbTimerDO7.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO7.TabIndex = 92;
            this.tbTimerDO7.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD07
            // 
            this.lbD07.AutoSize = true;
            this.lbD07.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD07.ForeColor = System.Drawing.Color.LightGray;
            this.lbD07.Location = new System.Drawing.Point(19, 15);
            this.lbD07.Name = "lbD07";
            this.lbD07.Size = new System.Drawing.Size(39, 27);
            this.lbD07.TabIndex = 45;
            this.lbD07.Text = "●";
            // 
            // cbTimerDO7
            // 
            this.cbTimerDO7.AutoSize = true;
            this.cbTimerDO7.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO7.Name = "cbTimerDO7";
            this.cbTimerDO7.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO7.TabIndex = 90;
            this.cbTimerDO7.UseVisualStyleBackColor = true;
            // 
            // laDO7
            // 
            this.laDO7.AutoSize = true;
            this.laDO7.Location = new System.Drawing.Point(129, 79);
            this.laDO7.Name = "laDO7";
            this.laDO7.Size = new System.Drawing.Size(21, 14);
            this.laDO7.TabIndex = 91;
            this.laDO7.Text = "秒";
            this.laDO7.Visible = false;
            // 
            // lbSec7
            // 
            this.lbSec7.AutoSize = true;
            this.lbSec7.Location = new System.Drawing.Point(129, 106);
            this.lbSec7.Name = "lbSec7";
            this.lbSec7.Size = new System.Drawing.Size(21, 14);
            this.lbSec7.TabIndex = 72;
            this.lbSec7.Text = "秒";
            this.lbSec7.Visible = false;
            // 
            // gbDO6
            // 
            this.gbDO6.Controls.Add(this.cbWait6);
            this.gbDO6.Controls.Add(this.btnExcute6);
            this.gbDO6.Controls.Add(this.lbWait6);
            this.gbDO6.Controls.Add(this.cbMode6);
            this.gbDO6.Controls.Add(this.txtWaitTime6);
            this.gbDO6.Controls.Add(this.laDlyDO6);
            this.gbDO6.Controls.Add(this.labelDO6);
            this.gbDO6.Controls.Add(this.tbTimerDO6);
            this.gbDO6.Controls.Add(this.lbD06);
            this.gbDO6.Controls.Add(this.cbTimerDO6);
            this.gbDO6.Controls.Add(this.lbSec6);
            this.gbDO6.Controls.Add(this.laDO6);
            this.gbDO6.Location = new System.Drawing.Point(167, 173);
            this.gbDO6.Name = "gbDO6";
            this.gbDO6.Size = new System.Drawing.Size(160, 127);
            this.gbDO6.TabIndex = 75;
            this.gbDO6.TabStop = false;
            this.gbDO6.Text = "6";
            // 
            // cbWait6
            // 
            this.cbWait6.AutoSize = true;
            this.cbWait6.Location = new System.Drawing.Point(5, 106);
            this.cbWait6.Name = "cbWait6";
            this.cbWait6.Size = new System.Drawing.Size(15, 14);
            this.cbWait6.TabIndex = 80;
            this.cbWait6.UseVisualStyleBackColor = true;
            // 
            // btnExcute6
            // 
            this.btnExcute6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute6.Location = new System.Drawing.Point(76, 43);
            this.btnExcute6.Name = "btnExcute6";
            this.btnExcute6.Size = new System.Drawing.Size(79, 27);
            this.btnExcute6.TabIndex = 78;
            this.btnExcute6.Text = "执行";
            this.btnExcute6.UseVisualStyleBackColor = true;
            this.btnExcute6.Click += new System.EventHandler(this.btnExcute6_Click);
            // 
            // lbWait6
            // 
            this.lbWait6.AutoSize = true;
            this.lbWait6.Location = new System.Drawing.Point(26, 107);
            this.lbWait6.Name = "lbWait6";
            this.lbWait6.Size = new System.Drawing.Size(35, 14);
            this.lbWait6.TabIndex = 79;
            this.lbWait6.Text = "等待";
            // 
            // cbMode6
            // 
            this.cbMode6.FormattingEnabled = true;
            this.cbMode6.Location = new System.Drawing.Point(76, 13);
            this.cbMode6.Name = "cbMode6";
            this.cbMode6.Size = new System.Drawing.Size(78, 22);
            this.cbMode6.TabIndex = 76;
            this.cbMode6.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // txtWaitTime6
            // 
            this.txtWaitTime6.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime6.Name = "txtWaitTime6";
            this.txtWaitTime6.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime6.TabIndex = 77;
            this.txtWaitTime6.Visible = false;
            this.txtWaitTime6.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // laDlyDO6
            // 
            this.laDlyDO6.AutoSize = true;
            this.laDlyDO6.Location = new System.Drawing.Point(26, 49);
            this.laDlyDO6.Name = "laDlyDO6";
            this.laDlyDO6.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO6.TabIndex = 93;
            this.laDlyDO6.Text = "D06";
            // 
            // labelDO6
            // 
            this.labelDO6.AutoSize = true;
            this.labelDO6.Location = new System.Drawing.Point(27, 79);
            this.labelDO6.Name = "labelDO6";
            this.labelDO6.Size = new System.Drawing.Size(35, 14);
            this.labelDO6.TabIndex = 92;
            this.labelDO6.Text = "延时";
            // 
            // tbTimerDO6
            // 
            this.tbTimerDO6.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO6.Name = "tbTimerDO6";
            this.tbTimerDO6.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO6.TabIndex = 91;
            this.tbTimerDO6.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD06
            // 
            this.lbD06.AutoSize = true;
            this.lbD06.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD06.ForeColor = System.Drawing.Color.LightGray;
            this.lbD06.Location = new System.Drawing.Point(19, 15);
            this.lbD06.Name = "lbD06";
            this.lbD06.Size = new System.Drawing.Size(39, 27);
            this.lbD06.TabIndex = 43;
            this.lbD06.Text = "●";
            // 
            // cbTimerDO6
            // 
            this.cbTimerDO6.AutoSize = true;
            this.cbTimerDO6.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO6.Name = "cbTimerDO6";
            this.cbTimerDO6.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO6.TabIndex = 89;
            this.cbTimerDO6.UseVisualStyleBackColor = true;
            // 
            // lbSec6
            // 
            this.lbSec6.AutoSize = true;
            this.lbSec6.Location = new System.Drawing.Point(131, 106);
            this.lbSec6.Name = "lbSec6";
            this.lbSec6.Size = new System.Drawing.Size(21, 14);
            this.lbSec6.TabIndex = 72;
            this.lbSec6.Text = "秒";
            this.lbSec6.Visible = false;
            // 
            // laDO6
            // 
            this.laDO6.AutoSize = true;
            this.laDO6.Location = new System.Drawing.Point(131, 81);
            this.laDO6.Name = "laDO6";
            this.laDO6.Size = new System.Drawing.Size(21, 14);
            this.laDO6.TabIndex = 90;
            this.laDO6.Text = "秒";
            this.laDO6.Visible = false;
            // 
            // gbDO5
            // 
            this.gbDO5.Controls.Add(this.cbWait5);
            this.gbDO5.Controls.Add(this.lbWait5);
            this.gbDO5.Controls.Add(this.btnExcute5);
            this.gbDO5.Controls.Add(this.txtWaitTime5);
            this.gbDO5.Controls.Add(this.cbMode5);
            this.gbDO5.Controls.Add(this.laDlyDO5);
            this.gbDO5.Controls.Add(this.labelDO5);
            this.gbDO5.Controls.Add(this.tbTimerDO5);
            this.gbDO5.Controls.Add(this.lbSec5);
            this.gbDO5.Controls.Add(this.lbD05);
            this.gbDO5.Controls.Add(this.cbTimerDO5);
            this.gbDO5.Controls.Add(this.laDO5);
            this.gbDO5.Location = new System.Drawing.Point(6, 173);
            this.gbDO5.Name = "gbDO5";
            this.gbDO5.Size = new System.Drawing.Size(160, 127);
            this.gbDO5.TabIndex = 74;
            this.gbDO5.TabStop = false;
            this.gbDO5.Text = "5";
            // 
            // cbWait5
            // 
            this.cbWait5.AutoSize = true;
            this.cbWait5.Location = new System.Drawing.Point(5, 103);
            this.cbWait5.Name = "cbWait5";
            this.cbWait5.Size = new System.Drawing.Size(15, 14);
            this.cbWait5.TabIndex = 80;
            this.cbWait5.UseVisualStyleBackColor = true;
            // 
            // lbWait5
            // 
            this.lbWait5.AutoSize = true;
            this.lbWait5.Location = new System.Drawing.Point(24, 106);
            this.lbWait5.Name = "lbWait5";
            this.lbWait5.Size = new System.Drawing.Size(35, 14);
            this.lbWait5.TabIndex = 79;
            this.lbWait5.Text = "等待";
            // 
            // btnExcute5
            // 
            this.btnExcute5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute5.Location = new System.Drawing.Point(76, 43);
            this.btnExcute5.Name = "btnExcute5";
            this.btnExcute5.Size = new System.Drawing.Size(79, 27);
            this.btnExcute5.TabIndex = 78;
            this.btnExcute5.Text = "执行";
            this.btnExcute5.UseVisualStyleBackColor = true;
            this.btnExcute5.Click += new System.EventHandler(this.btnExcute5_Click);
            // 
            // txtWaitTime5
            // 
            this.txtWaitTime5.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime5.Name = "txtWaitTime5";
            this.txtWaitTime5.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime5.TabIndex = 77;
            this.txtWaitTime5.Visible = false;
            this.txtWaitTime5.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbMode5
            // 
            this.cbMode5.FormattingEnabled = true;
            this.cbMode5.Location = new System.Drawing.Point(76, 15);
            this.cbMode5.Name = "cbMode5";
            this.cbMode5.Size = new System.Drawing.Size(79, 22);
            this.cbMode5.TabIndex = 76;
            this.cbMode5.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO5
            // 
            this.laDlyDO5.AutoSize = true;
            this.laDlyDO5.Location = new System.Drawing.Point(31, 49);
            this.laDlyDO5.Name = "laDlyDO5";
            this.laDlyDO5.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO5.TabIndex = 92;
            this.laDlyDO5.Text = "D05";
            // 
            // labelDO5
            // 
            this.labelDO5.AutoSize = true;
            this.labelDO5.Location = new System.Drawing.Point(27, 79);
            this.labelDO5.Name = "labelDO5";
            this.labelDO5.Size = new System.Drawing.Size(35, 14);
            this.labelDO5.TabIndex = 91;
            this.labelDO5.Text = "延时";
            // 
            // tbTimerDO5
            // 
            this.tbTimerDO5.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO5.Name = "tbTimerDO5";
            this.tbTimerDO5.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO5.TabIndex = 90;
            this.tbTimerDO5.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbSec5
            // 
            this.lbSec5.AutoSize = true;
            this.lbSec5.Location = new System.Drawing.Point(126, 105);
            this.lbSec5.Name = "lbSec5";
            this.lbSec5.Size = new System.Drawing.Size(21, 14);
            this.lbSec5.TabIndex = 72;
            this.lbSec5.Text = "秒";
            this.lbSec5.Visible = false;
            // 
            // lbD05
            // 
            this.lbD05.AutoSize = true;
            this.lbD05.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD05.ForeColor = System.Drawing.Color.LightGray;
            this.lbD05.Location = new System.Drawing.Point(25, 15);
            this.lbD05.Name = "lbD05";
            this.lbD05.Size = new System.Drawing.Size(39, 27);
            this.lbD05.TabIndex = 41;
            this.lbD05.Text = "●";
            // 
            // cbTimerDO5
            // 
            this.cbTimerDO5.AutoSize = true;
            this.cbTimerDO5.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO5.Name = "cbTimerDO5";
            this.cbTimerDO5.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO5.TabIndex = 88;
            this.cbTimerDO5.UseVisualStyleBackColor = true;
            // 
            // laDO5
            // 
            this.laDO5.AutoSize = true;
            this.laDO5.Location = new System.Drawing.Point(126, 81);
            this.laDO5.Name = "laDO5";
            this.laDO5.Size = new System.Drawing.Size(21, 14);
            this.laDO5.TabIndex = 89;
            this.laDO5.Text = "秒";
            this.laDO5.Visible = false;
            // 
            // gbDO4
            // 
            this.gbDO4.Controls.Add(this.cbWait4);
            this.gbDO4.Controls.Add(this.lbWait4);
            this.gbDO4.Controls.Add(this.btnExcute4);
            this.gbDO4.Controls.Add(this.cbMode4);
            this.gbDO4.Controls.Add(this.laDlyDO4);
            this.gbDO4.Controls.Add(this.labelDO4);
            this.gbDO4.Controls.Add(this.txtWaitTime4);
            this.gbDO4.Controls.Add(this.tbTimerDO4);
            this.gbDO4.Controls.Add(this.lbD04);
            this.gbDO4.Controls.Add(this.cbTimerDO4);
            this.gbDO4.Controls.Add(this.laDO4);
            this.gbDO4.Controls.Add(this.lbSec4);
            this.gbDO4.Location = new System.Drawing.Point(487, 46);
            this.gbDO4.Name = "gbDO4";
            this.gbDO4.Size = new System.Drawing.Size(160, 127);
            this.gbDO4.TabIndex = 73;
            this.gbDO4.TabStop = false;
            this.gbDO4.Text = "4";
            // 
            // cbWait4
            // 
            this.cbWait4.AutoSize = true;
            this.cbWait4.Location = new System.Drawing.Point(5, 104);
            this.cbWait4.Name = "cbWait4";
            this.cbWait4.Size = new System.Drawing.Size(15, 14);
            this.cbWait4.TabIndex = 80;
            this.cbWait4.UseVisualStyleBackColor = true;
            // 
            // lbWait4
            // 
            this.lbWait4.AutoSize = true;
            this.lbWait4.Location = new System.Drawing.Point(26, 104);
            this.lbWait4.Name = "lbWait4";
            this.lbWait4.Size = new System.Drawing.Size(35, 14);
            this.lbWait4.TabIndex = 79;
            this.lbWait4.Text = "等待";
            // 
            // btnExcute4
            // 
            this.btnExcute4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute4.Location = new System.Drawing.Point(75, 43);
            this.btnExcute4.Name = "btnExcute4";
            this.btnExcute4.Size = new System.Drawing.Size(79, 27);
            this.btnExcute4.TabIndex = 78;
            this.btnExcute4.Text = "执行";
            this.btnExcute4.UseVisualStyleBackColor = true;
            this.btnExcute4.Click += new System.EventHandler(this.btnExcute4_Click);
            // 
            // cbMode4
            // 
            this.cbMode4.FormattingEnabled = true;
            this.cbMode4.Location = new System.Drawing.Point(75, 15);
            this.cbMode4.Name = "cbMode4";
            this.cbMode4.Size = new System.Drawing.Size(79, 22);
            this.cbMode4.TabIndex = 76;
            this.cbMode4.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO4
            // 
            this.laDlyDO4.AutoSize = true;
            this.laDlyDO4.Location = new System.Drawing.Point(29, 50);
            this.laDlyDO4.Name = "laDlyDO4";
            this.laDlyDO4.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO4.TabIndex = 91;
            this.laDlyDO4.Text = "D04";
            // 
            // labelDO4
            // 
            this.labelDO4.AutoSize = true;
            this.labelDO4.Location = new System.Drawing.Point(27, 79);
            this.labelDO4.Name = "labelDO4";
            this.labelDO4.Size = new System.Drawing.Size(35, 14);
            this.labelDO4.TabIndex = 90;
            this.labelDO4.Text = "延时";
            // 
            // txtWaitTime4
            // 
            this.txtWaitTime4.Location = new System.Drawing.Point(75, 101);
            this.txtWaitTime4.Name = "txtWaitTime4";
            this.txtWaitTime4.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime4.TabIndex = 77;
            this.txtWaitTime4.Visible = false;
            this.txtWaitTime4.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // tbTimerDO4
            // 
            this.tbTimerDO4.Location = new System.Drawing.Point(75, 76);
            this.tbTimerDO4.Name = "tbTimerDO4";
            this.tbTimerDO4.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO4.TabIndex = 89;
            this.tbTimerDO4.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD04
            // 
            this.lbD04.AutoSize = true;
            this.lbD04.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD04.ForeColor = System.Drawing.Color.LightGray;
            this.lbD04.Location = new System.Drawing.Point(22, 15);
            this.lbD04.Name = "lbD04";
            this.lbD04.Size = new System.Drawing.Size(39, 27);
            this.lbD04.TabIndex = 39;
            this.lbD04.Text = "●";
            // 
            // cbTimerDO4
            // 
            this.cbTimerDO4.AutoSize = true;
            this.cbTimerDO4.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO4.Name = "cbTimerDO4";
            this.cbTimerDO4.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO4.TabIndex = 87;
            this.cbTimerDO4.UseVisualStyleBackColor = true;
            // 
            // laDO4
            // 
            this.laDO4.AutoSize = true;
            this.laDO4.Location = new System.Drawing.Point(125, 80);
            this.laDO4.Name = "laDO4";
            this.laDO4.Size = new System.Drawing.Size(21, 14);
            this.laDO4.TabIndex = 88;
            this.laDO4.Text = "秒";
            this.laDO4.Visible = false;
            // 
            // lbSec4
            // 
            this.lbSec4.AutoSize = true;
            this.lbSec4.Location = new System.Drawing.Point(125, 107);
            this.lbSec4.Name = "lbSec4";
            this.lbSec4.Size = new System.Drawing.Size(21, 14);
            this.lbSec4.TabIndex = 72;
            this.lbSec4.Text = "秒";
            this.lbSec4.Visible = false;
            // 
            // gbDO3
            // 
            this.gbDO3.Controls.Add(this.cbWait3);
            this.gbDO3.Controls.Add(this.lbWait3);
            this.gbDO3.Controls.Add(this.btnExcute3);
            this.gbDO3.Controls.Add(this.cbMode3);
            this.gbDO3.Controls.Add(this.laDlyDO3);
            this.gbDO3.Controls.Add(this.txtWaitTime3);
            this.gbDO3.Controls.Add(this.labelDO3);
            this.gbDO3.Controls.Add(this.tbTimerDO3);
            this.gbDO3.Controls.Add(this.lbD03);
            this.gbDO3.Controls.Add(this.cbTimerDO3);
            this.gbDO3.Controls.Add(this.lbSec3);
            this.gbDO3.Controls.Add(this.laDO3);
            this.gbDO3.Location = new System.Drawing.Point(326, 46);
            this.gbDO3.Name = "gbDO3";
            this.gbDO3.Size = new System.Drawing.Size(160, 127);
            this.gbDO3.TabIndex = 72;
            this.gbDO3.TabStop = false;
            this.gbDO3.Text = "3";
            // 
            // cbWait3
            // 
            this.cbWait3.AutoSize = true;
            this.cbWait3.Location = new System.Drawing.Point(4, 105);
            this.cbWait3.Name = "cbWait3";
            this.cbWait3.Size = new System.Drawing.Size(15, 14);
            this.cbWait3.TabIndex = 80;
            this.cbWait3.UseVisualStyleBackColor = true;
            // 
            // lbWait3
            // 
            this.lbWait3.AutoSize = true;
            this.lbWait3.Location = new System.Drawing.Point(27, 107);
            this.lbWait3.Name = "lbWait3";
            this.lbWait3.Size = new System.Drawing.Size(35, 14);
            this.lbWait3.TabIndex = 79;
            this.lbWait3.Text = "等待";
            // 
            // btnExcute3
            // 
            this.btnExcute3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute3.Location = new System.Drawing.Point(74, 43);
            this.btnExcute3.Name = "btnExcute3";
            this.btnExcute3.Size = new System.Drawing.Size(79, 27);
            this.btnExcute3.TabIndex = 78;
            this.btnExcute3.Text = "执行";
            this.btnExcute3.UseVisualStyleBackColor = true;
            this.btnExcute3.Click += new System.EventHandler(this.btnExcute3_Click);
            // 
            // cbMode3
            // 
            this.cbMode3.FormattingEnabled = true;
            this.cbMode3.Location = new System.Drawing.Point(74, 15);
            this.cbMode3.Name = "cbMode3";
            this.cbMode3.Size = new System.Drawing.Size(79, 22);
            this.cbMode3.TabIndex = 76;
            this.cbMode3.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO3
            // 
            this.laDlyDO3.AutoSize = true;
            this.laDlyDO3.Location = new System.Drawing.Point(30, 50);
            this.laDlyDO3.Name = "laDlyDO3";
            this.laDlyDO3.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO3.TabIndex = 90;
            this.laDlyDO3.Text = "DO3";
            // 
            // txtWaitTime3
            // 
            this.txtWaitTime3.Location = new System.Drawing.Point(74, 101);
            this.txtWaitTime3.Name = "txtWaitTime3";
            this.txtWaitTime3.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime3.TabIndex = 77;
            this.txtWaitTime3.Visible = false;
            this.txtWaitTime3.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // labelDO3
            // 
            this.labelDO3.AutoSize = true;
            this.labelDO3.Location = new System.Drawing.Point(27, 79);
            this.labelDO3.Name = "labelDO3";
            this.labelDO3.Size = new System.Drawing.Size(35, 14);
            this.labelDO3.TabIndex = 89;
            this.labelDO3.Text = "延时";
            // 
            // tbTimerDO3
            // 
            this.tbTimerDO3.Location = new System.Drawing.Point(74, 76);
            this.tbTimerDO3.Name = "tbTimerDO3";
            this.tbTimerDO3.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO3.TabIndex = 88;
            this.tbTimerDO3.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbD03
            // 
            this.lbD03.AutoSize = true;
            this.lbD03.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD03.ForeColor = System.Drawing.Color.LightGray;
            this.lbD03.Location = new System.Drawing.Point(22, 15);
            this.lbD03.Name = "lbD03";
            this.lbD03.Size = new System.Drawing.Size(39, 27);
            this.lbD03.TabIndex = 37;
            this.lbD03.Text = "●";
            // 
            // cbTimerDO3
            // 
            this.cbTimerDO3.AutoSize = true;
            this.cbTimerDO3.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO3.Name = "cbTimerDO3";
            this.cbTimerDO3.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO3.TabIndex = 86;
            this.cbTimerDO3.UseVisualStyleBackColor = true;
            // 
            // lbSec3
            // 
            this.lbSec3.AutoSize = true;
            this.lbSec3.Location = new System.Drawing.Point(129, 104);
            this.lbSec3.Name = "lbSec3";
            this.lbSec3.Size = new System.Drawing.Size(21, 14);
            this.lbSec3.TabIndex = 72;
            this.lbSec3.Text = "秒";
            this.lbSec3.Visible = false;
            // 
            // laDO3
            // 
            this.laDO3.AutoSize = true;
            this.laDO3.Location = new System.Drawing.Point(129, 80);
            this.laDO3.Name = "laDO3";
            this.laDO3.Size = new System.Drawing.Size(21, 14);
            this.laDO3.TabIndex = 87;
            this.laDO3.Text = "秒";
            this.laDO3.Visible = false;
            // 
            // gbDO2
            // 
            this.gbDO2.Controls.Add(this.cbWait2);
            this.gbDO2.Controls.Add(this.lbWait2);
            this.gbDO2.Controls.Add(this.btnExcute2);
            this.gbDO2.Controls.Add(this.cbMode2);
            this.gbDO2.Controls.Add(this.txtWaitTime2);
            this.gbDO2.Controls.Add(this.laDlyDO2);
            this.gbDO2.Controls.Add(this.labelDO2);
            this.gbDO2.Controls.Add(this.tbTimerDO2);
            this.gbDO2.Controls.Add(this.lbSec2);
            this.gbDO2.Controls.Add(this.cbTimerDO2);
            this.gbDO2.Controls.Add(this.lbD02);
            this.gbDO2.Controls.Add(this.laDO2);
            this.gbDO2.Location = new System.Drawing.Point(167, 46);
            this.gbDO2.Name = "gbDO2";
            this.gbDO2.Size = new System.Drawing.Size(160, 127);
            this.gbDO2.TabIndex = 71;
            this.gbDO2.TabStop = false;
            this.gbDO2.Text = "2";
            // 
            // cbWait2
            // 
            this.cbWait2.AutoSize = true;
            this.cbWait2.Location = new System.Drawing.Point(4, 105);
            this.cbWait2.Name = "cbWait2";
            this.cbWait2.Size = new System.Drawing.Size(15, 14);
            this.cbWait2.TabIndex = 80;
            this.cbWait2.UseVisualStyleBackColor = true;
            // 
            // lbWait2
            // 
            this.lbWait2.AutoSize = true;
            this.lbWait2.Location = new System.Drawing.Point(27, 107);
            this.lbWait2.Name = "lbWait2";
            this.lbWait2.Size = new System.Drawing.Size(35, 14);
            this.lbWait2.TabIndex = 79;
            this.lbWait2.Text = "等待";
            // 
            // btnExcute2
            // 
            this.btnExcute2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute2.Location = new System.Drawing.Point(76, 43);
            this.btnExcute2.Name = "btnExcute2";
            this.btnExcute2.Size = new System.Drawing.Size(79, 27);
            this.btnExcute2.TabIndex = 78;
            this.btnExcute2.Text = "执行";
            this.btnExcute2.UseVisualStyleBackColor = true;
            this.btnExcute2.Click += new System.EventHandler(this.btnExcute2_Click);
            // 
            // cbMode2
            // 
            this.cbMode2.FormattingEnabled = true;
            this.cbMode2.Location = new System.Drawing.Point(76, 15);
            this.cbMode2.Name = "cbMode2";
            this.cbMode2.Size = new System.Drawing.Size(79, 22);
            this.cbMode2.TabIndex = 76;
            this.cbMode2.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // txtWaitTime2
            // 
            this.txtWaitTime2.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime2.Name = "txtWaitTime2";
            this.txtWaitTime2.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime2.TabIndex = 77;
            this.txtWaitTime2.Visible = false;
            this.txtWaitTime2.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // laDlyDO2
            // 
            this.laDlyDO2.AutoSize = true;
            this.laDlyDO2.Location = new System.Drawing.Point(30, 50);
            this.laDlyDO2.Name = "laDlyDO2";
            this.laDlyDO2.Size = new System.Drawing.Size(28, 14);
            this.laDlyDO2.TabIndex = 89;
            this.laDlyDO2.Text = "DO2";
            // 
            // labelDO2
            // 
            this.labelDO2.AutoSize = true;
            this.labelDO2.Location = new System.Drawing.Point(27, 79);
            this.labelDO2.Name = "labelDO2";
            this.labelDO2.Size = new System.Drawing.Size(35, 14);
            this.labelDO2.TabIndex = 88;
            this.labelDO2.Text = "延时";
            // 
            // tbTimerDO2
            // 
            this.tbTimerDO2.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO2.Name = "tbTimerDO2";
            this.tbTimerDO2.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO2.TabIndex = 87;
            this.tbTimerDO2.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // lbSec2
            // 
            this.lbSec2.AutoSize = true;
            this.lbSec2.Location = new System.Drawing.Point(131, 105);
            this.lbSec2.Name = "lbSec2";
            this.lbSec2.Size = new System.Drawing.Size(21, 14);
            this.lbSec2.TabIndex = 72;
            this.lbSec2.Text = "秒";
            this.lbSec2.Visible = false;
            // 
            // cbTimerDO2
            // 
            this.cbTimerDO2.AutoSize = true;
            this.cbTimerDO2.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO2.Name = "cbTimerDO2";
            this.cbTimerDO2.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO2.TabIndex = 72;
            this.cbTimerDO2.UseVisualStyleBackColor = true;
            // 
            // lbD02
            // 
            this.lbD02.AutoSize = true;
            this.lbD02.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD02.ForeColor = System.Drawing.Color.LightGray;
            this.lbD02.Location = new System.Drawing.Point(22, 15);
            this.lbD02.Name = "lbD02";
            this.lbD02.Size = new System.Drawing.Size(39, 27);
            this.lbD02.TabIndex = 35;
            this.lbD02.Text = "●";
            // 
            // laDO2
            // 
            this.laDO2.AutoSize = true;
            this.laDO2.Location = new System.Drawing.Point(131, 80);
            this.laDO2.Name = "laDO2";
            this.laDO2.Size = new System.Drawing.Size(21, 14);
            this.laDO2.TabIndex = 86;
            this.laDO2.Text = "秒";
            this.laDO2.Visible = false;
            // 
            // gbDO1
            // 
            this.gbDO1.Controls.Add(this.cbWait1);
            this.gbDO1.Controls.Add(this.btnExcute1);
            this.gbDO1.Controls.Add(this.lbWait1);
            this.gbDO1.Controls.Add(this.cbMode1);
            this.gbDO1.Controls.Add(this.laDlyDO1);
            this.gbDO1.Controls.Add(this.labelDO1);
            this.gbDO1.Controls.Add(this.txtWaitTime1);
            this.gbDO1.Controls.Add(this.laDO1);
            this.gbDO1.Controls.Add(this.tbTimerDO1);
            this.gbDO1.Controls.Add(this.cbTimerDO1);
            this.gbDO1.Controls.Add(this.lbD01);
            this.gbDO1.Controls.Add(this.lbSec1);
            this.gbDO1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbDO1.Location = new System.Drawing.Point(6, 46);
            this.gbDO1.Name = "gbDO1";
            this.gbDO1.Size = new System.Drawing.Size(160, 127);
            this.gbDO1.TabIndex = 70;
            this.gbDO1.TabStop = false;
            this.gbDO1.Text = "1";
            // 
            // cbWait1
            // 
            this.cbWait1.AutoSize = true;
            this.cbWait1.Location = new System.Drawing.Point(5, 105);
            this.cbWait1.Name = "cbWait1";
            this.cbWait1.Size = new System.Drawing.Size(15, 14);
            this.cbWait1.TabIndex = 80;
            this.cbWait1.UseVisualStyleBackColor = true;
            // 
            // btnExcute1
            // 
            this.btnExcute1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcute1.Location = new System.Drawing.Point(75, 43);
            this.btnExcute1.Name = "btnExcute1";
            this.btnExcute1.Size = new System.Drawing.Size(79, 27);
            this.btnExcute1.TabIndex = 78;
            this.btnExcute1.Text = "执行";
            this.btnExcute1.UseVisualStyleBackColor = true;
            this.btnExcute1.Click += new System.EventHandler(this.btnExcute1_Click);
            // 
            // lbWait1
            // 
            this.lbWait1.AutoSize = true;
            this.lbWait1.Location = new System.Drawing.Point(27, 104);
            this.lbWait1.Name = "lbWait1";
            this.lbWait1.Size = new System.Drawing.Size(35, 14);
            this.lbWait1.TabIndex = 79;
            this.lbWait1.Text = "等待";
            // 
            // cbMode1
            // 
            this.cbMode1.FormattingEnabled = true;
            this.cbMode1.Location = new System.Drawing.Point(76, 15);
            this.cbMode1.Name = "cbMode1";
            this.cbMode1.Size = new System.Drawing.Size(79, 22);
            this.cbMode1.TabIndex = 76;
            this.cbMode1.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
            // 
            // laDlyDO1
            // 
            this.laDlyDO1.Location = new System.Drawing.Point(17, 50);
            this.laDlyDO1.Name = "laDlyDO1";
            this.laDlyDO1.Size = new System.Drawing.Size(52, 14);
            this.laDlyDO1.TabIndex = 75;
            this.laDlyDO1.Text = "DO1";
            this.laDlyDO1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDO1
            // 
            this.labelDO1.AutoSize = true;
            this.labelDO1.Location = new System.Drawing.Point(27, 79);
            this.labelDO1.Name = "labelDO1";
            this.labelDO1.Size = new System.Drawing.Size(35, 14);
            this.labelDO1.TabIndex = 74;
            this.labelDO1.Text = "延时";
            // 
            // txtWaitTime1
            // 
            this.txtWaitTime1.Location = new System.Drawing.Point(76, 101);
            this.txtWaitTime1.Name = "txtWaitTime1";
            this.txtWaitTime1.Size = new System.Drawing.Size(49, 23);
            this.txtWaitTime1.TabIndex = 77;
            this.txtWaitTime1.Visible = false;
            this.txtWaitTime1.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.txtWaitTime1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // laDO1
            // 
            this.laDO1.AutoSize = true;
            this.laDO1.Location = new System.Drawing.Point(126, 80);
            this.laDO1.Name = "laDO1";
            this.laDO1.Size = new System.Drawing.Size(21, 14);
            this.laDO1.TabIndex = 72;
            this.laDO1.Text = "秒";
            this.laDO1.Visible = false;
            // 
            // tbTimerDO1
            // 
            this.tbTimerDO1.Location = new System.Drawing.Point(76, 76);
            this.tbTimerDO1.Name = "tbTimerDO1";
            this.tbTimerDO1.Size = new System.Drawing.Size(49, 23);
            this.tbTimerDO1.TabIndex = 71;
            this.tbTimerDO1.TextChanged += new System.EventHandler(this.tbTimerDO0_TextChanged);
            this.tbTimerDO1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtWaitTime1_MouseMove);
            // 
            // cbTimerDO1
            // 
            this.cbTimerDO1.AutoSize = true;
            this.cbTimerDO1.Location = new System.Drawing.Point(5, 79);
            this.cbTimerDO1.Name = "cbTimerDO1";
            this.cbTimerDO1.Size = new System.Drawing.Size(15, 14);
            this.cbTimerDO1.TabIndex = 71;
            this.cbTimerDO1.UseVisualStyleBackColor = true;
            // 
            // lbD01
            // 
            this.lbD01.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbD01.AutoSize = true;
            this.lbD01.Font = new System.Drawing.Font("宋体", 20F);
            this.lbD01.ForeColor = System.Drawing.Color.LightGray;
            this.lbD01.Location = new System.Drawing.Point(25, 15);
            this.lbD01.Name = "lbD01";
            this.lbD01.Size = new System.Drawing.Size(39, 27);
            this.lbD01.TabIndex = 33;
            this.lbD01.Text = "●";
            // 
            // lbSec1
            // 
            this.lbSec1.AutoSize = true;
            this.lbSec1.Location = new System.Drawing.Point(126, 104);
            this.lbSec1.Name = "lbSec1";
            this.lbSec1.Size = new System.Drawing.Size(21, 14);
            this.lbSec1.TabIndex = 72;
            this.lbSec1.Text = "秒";
            this.lbSec1.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.lbDI16);
            this.groupBox3.Controls.Add(this.lbSixTeen);
            this.groupBox3.Controls.Add(this.lbDI15);
            this.groupBox3.Controls.Add(this.lbFifthTeen);
            this.groupBox3.Controls.Add(this.lbDI14);
            this.groupBox3.Controls.Add(this.lbFourTeen);
            this.groupBox3.Controls.Add(this.lbDI13);
            this.groupBox3.Controls.Add(this.lbThirTeen);
            this.groupBox3.Controls.Add(this.lbDI12);
            this.groupBox3.Controls.Add(this.lbTwelve);
            this.groupBox3.Controls.Add(this.lbDI11);
            this.groupBox3.Controls.Add(this.lbElevent);
            this.groupBox3.Controls.Add(this.lbDI10);
            this.groupBox3.Controls.Add(this.lbTen);
            this.groupBox3.Controls.Add(this.lbDI9);
            this.groupBox3.Controls.Add(this.lbNine);
            this.groupBox3.Controls.Add(this.lbDI8);
            this.groupBox3.Controls.Add(this.lbEight);
            this.groupBox3.Controls.Add(this.lbDI7);
            this.groupBox3.Controls.Add(this.lbServen);
            this.groupBox3.Controls.Add(this.lbDI6);
            this.groupBox3.Controls.Add(this.lbSix);
            this.groupBox3.Controls.Add(this.lbDI5);
            this.groupBox3.Controls.Add(this.lbFive);
            this.groupBox3.Controls.Add(this.lbDI4);
            this.groupBox3.Controls.Add(this.lbFour);
            this.groupBox3.Controls.Add(this.lbDI3);
            this.groupBox3.Controls.Add(this.lbThree);
            this.groupBox3.Controls.Add(this.lbDI2);
            this.groupBox3.Controls.Add(this.lbTwo);
            this.groupBox3.Controls.Add(this.lbDI1);
            this.groupBox3.Controls.Add(this.lbOne);
            this.groupBox3.Location = new System.Drawing.Point(660, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(405, 568);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(143, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 29);
            this.label4.TabIndex = 32;
            this.label4.Text = "输入(INPUT)";
            // 
            // lbDI16
            // 
            this.lbDI16.AutoSize = true;
            this.lbDI16.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI16.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI16.Location = new System.Drawing.Point(299, 439);
            this.lbDI16.Name = "lbDI16";
            this.lbDI16.Size = new System.Drawing.Size(80, 56);
            this.lbDI16.TabIndex = 31;
            this.lbDI16.Text = "●";
            // 
            // lbSixTeen
            // 
            this.lbSixTeen.AutoSize = true;
            this.lbSixTeen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold);
            this.lbSixTeen.Location = new System.Drawing.Point(317, 504);
            this.lbSixTeen.Name = "lbSixTeen";
            this.lbSixTeen.Size = new System.Drawing.Size(45, 29);
            this.lbSixTeen.TabIndex = 30;
            this.lbSixTeen.Text = "16";
            // 
            // lbDI15
            // 
            this.lbDI15.AutoSize = true;
            this.lbDI15.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI15.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI15.Location = new System.Drawing.Point(208, 439);
            this.lbDI15.Name = "lbDI15";
            this.lbDI15.Size = new System.Drawing.Size(80, 56);
            this.lbDI15.TabIndex = 29;
            this.lbDI15.Text = "●";
            // 
            // lbFifthTeen
            // 
            this.lbFifthTeen.AutoSize = true;
            this.lbFifthTeen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold);
            this.lbFifthTeen.Location = new System.Drawing.Point(226, 504);
            this.lbFifthTeen.Name = "lbFifthTeen";
            this.lbFifthTeen.Size = new System.Drawing.Size(45, 29);
            this.lbFifthTeen.TabIndex = 28;
            this.lbFifthTeen.Text = "15";
            // 
            // lbDI14
            // 
            this.lbDI14.AutoSize = true;
            this.lbDI14.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI14.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI14.Location = new System.Drawing.Point(117, 439);
            this.lbDI14.Name = "lbDI14";
            this.lbDI14.Size = new System.Drawing.Size(80, 56);
            this.lbDI14.TabIndex = 27;
            this.lbDI14.Text = "●";
            // 
            // lbFourTeen
            // 
            this.lbFourTeen.AutoSize = true;
            this.lbFourTeen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold);
            this.lbFourTeen.Location = new System.Drawing.Point(135, 504);
            this.lbFourTeen.Name = "lbFourTeen";
            this.lbFourTeen.Size = new System.Drawing.Size(45, 29);
            this.lbFourTeen.TabIndex = 26;
            this.lbFourTeen.Text = "14";
            // 
            // lbDI13
            // 
            this.lbDI13.AutoSize = true;
            this.lbDI13.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI13.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI13.Location = new System.Drawing.Point(26, 439);
            this.lbDI13.Name = "lbDI13";
            this.lbDI13.Size = new System.Drawing.Size(80, 56);
            this.lbDI13.TabIndex = 25;
            this.lbDI13.Text = "●";
            // 
            // lbThirTeen
            // 
            this.lbThirTeen.AutoSize = true;
            this.lbThirTeen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold);
            this.lbThirTeen.Location = new System.Drawing.Point(44, 504);
            this.lbThirTeen.Name = "lbThirTeen";
            this.lbThirTeen.Size = new System.Drawing.Size(45, 29);
            this.lbThirTeen.TabIndex = 24;
            this.lbThirTeen.Text = "13";
            // 
            // lbDI12
            // 
            this.lbDI12.AutoSize = true;
            this.lbDI12.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI12.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI12.Location = new System.Drawing.Point(299, 320);
            this.lbDI12.Name = "lbDI12";
            this.lbDI12.Size = new System.Drawing.Size(80, 56);
            this.lbDI12.TabIndex = 23;
            this.lbDI12.Text = "●";
            // 
            // lbTwelve
            // 
            this.lbTwelve.AutoSize = true;
            this.lbTwelve.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTwelve.Location = new System.Drawing.Point(317, 382);
            this.lbTwelve.Name = "lbTwelve";
            this.lbTwelve.Size = new System.Drawing.Size(45, 29);
            this.lbTwelve.TabIndex = 22;
            this.lbTwelve.Text = "12";
            // 
            // lbDI11
            // 
            this.lbDI11.AutoSize = true;
            this.lbDI11.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI11.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI11.Location = new System.Drawing.Point(208, 320);
            this.lbDI11.Name = "lbDI11";
            this.lbDI11.Size = new System.Drawing.Size(80, 56);
            this.lbDI11.TabIndex = 21;
            this.lbDI11.Text = "●";
            // 
            // lbElevent
            // 
            this.lbElevent.AutoSize = true;
            this.lbElevent.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbElevent.Location = new System.Drawing.Point(226, 382);
            this.lbElevent.Name = "lbElevent";
            this.lbElevent.Size = new System.Drawing.Size(45, 29);
            this.lbElevent.TabIndex = 20;
            this.lbElevent.Text = "11";
            // 
            // lbDI10
            // 
            this.lbDI10.AutoSize = true;
            this.lbDI10.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI10.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI10.Location = new System.Drawing.Point(117, 320);
            this.lbDI10.Name = "lbDI10";
            this.lbDI10.Size = new System.Drawing.Size(80, 56);
            this.lbDI10.TabIndex = 19;
            this.lbDI10.Text = "●";
            // 
            // lbTen
            // 
            this.lbTen.AutoSize = true;
            this.lbTen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTen.Location = new System.Drawing.Point(135, 382);
            this.lbTen.Name = "lbTen";
            this.lbTen.Size = new System.Drawing.Size(45, 29);
            this.lbTen.TabIndex = 18;
            this.lbTen.Text = "10";
            // 
            // lbDI9
            // 
            this.lbDI9.AutoSize = true;
            this.lbDI9.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI9.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI9.Location = new System.Drawing.Point(26, 320);
            this.lbDI9.Name = "lbDI9";
            this.lbDI9.Size = new System.Drawing.Size(80, 56);
            this.lbDI9.TabIndex = 17;
            this.lbDI9.Text = "●";
            // 
            // lbNine
            // 
            this.lbNine.AutoSize = true;
            this.lbNine.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbNine.Location = new System.Drawing.Point(52, 382);
            this.lbNine.Name = "lbNine";
            this.lbNine.Size = new System.Drawing.Size(29, 29);
            this.lbNine.TabIndex = 16;
            this.lbNine.Text = "9";
            // 
            // lbDI8
            // 
            this.lbDI8.AutoSize = true;
            this.lbDI8.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI8.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI8.Location = new System.Drawing.Point(299, 201);
            this.lbDI8.Name = "lbDI8";
            this.lbDI8.Size = new System.Drawing.Size(80, 56);
            this.lbDI8.TabIndex = 15;
            this.lbDI8.Text = "●";
            // 
            // lbEight
            // 
            this.lbEight.AutoSize = true;
            this.lbEight.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbEight.Location = new System.Drawing.Point(325, 267);
            this.lbEight.Name = "lbEight";
            this.lbEight.Size = new System.Drawing.Size(29, 29);
            this.lbEight.TabIndex = 14;
            this.lbEight.Text = "8";
            // 
            // lbDI7
            // 
            this.lbDI7.AutoSize = true;
            this.lbDI7.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI7.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI7.Location = new System.Drawing.Point(208, 201);
            this.lbDI7.Name = "lbDI7";
            this.lbDI7.Size = new System.Drawing.Size(80, 56);
            this.lbDI7.TabIndex = 13;
            this.lbDI7.Text = "●";
            // 
            // lbServen
            // 
            this.lbServen.AutoSize = true;
            this.lbServen.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbServen.Location = new System.Drawing.Point(234, 267);
            this.lbServen.Name = "lbServen";
            this.lbServen.Size = new System.Drawing.Size(29, 29);
            this.lbServen.TabIndex = 12;
            this.lbServen.Text = "7";
            // 
            // lbDI6
            // 
            this.lbDI6.AutoSize = true;
            this.lbDI6.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI6.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI6.Location = new System.Drawing.Point(117, 201);
            this.lbDI6.Name = "lbDI6";
            this.lbDI6.Size = new System.Drawing.Size(80, 56);
            this.lbDI6.TabIndex = 11;
            this.lbDI6.Text = "●";
            // 
            // lbSix
            // 
            this.lbSix.AutoSize = true;
            this.lbSix.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbSix.Location = new System.Drawing.Point(143, 267);
            this.lbSix.Name = "lbSix";
            this.lbSix.Size = new System.Drawing.Size(29, 29);
            this.lbSix.TabIndex = 10;
            this.lbSix.Text = "6";
            // 
            // lbDI5
            // 
            this.lbDI5.AutoSize = true;
            this.lbDI5.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI5.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI5.Location = new System.Drawing.Point(26, 201);
            this.lbDI5.Name = "lbDI5";
            this.lbDI5.Size = new System.Drawing.Size(80, 56);
            this.lbDI5.TabIndex = 9;
            this.lbDI5.Text = "●";
            // 
            // lbFive
            // 
            this.lbFive.AutoSize = true;
            this.lbFive.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbFive.Location = new System.Drawing.Point(52, 267);
            this.lbFive.Name = "lbFive";
            this.lbFive.Size = new System.Drawing.Size(29, 29);
            this.lbFive.TabIndex = 8;
            this.lbFive.Text = "5";
            // 
            // lbDI4
            // 
            this.lbDI4.AutoSize = true;
            this.lbDI4.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI4.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI4.Location = new System.Drawing.Point(299, 82);
            this.lbDI4.Name = "lbDI4";
            this.lbDI4.Size = new System.Drawing.Size(80, 56);
            this.lbDI4.TabIndex = 7;
            this.lbDI4.Text = "●";
            // 
            // lbFour
            // 
            this.lbFour.AutoSize = true;
            this.lbFour.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbFour.Location = new System.Drawing.Point(325, 153);
            this.lbFour.Name = "lbFour";
            this.lbFour.Size = new System.Drawing.Size(29, 29);
            this.lbFour.TabIndex = 6;
            this.lbFour.Text = "4";
            // 
            // lbDI3
            // 
            this.lbDI3.AutoSize = true;
            this.lbDI3.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI3.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI3.Location = new System.Drawing.Point(208, 82);
            this.lbDI3.Name = "lbDI3";
            this.lbDI3.Size = new System.Drawing.Size(80, 56);
            this.lbDI3.TabIndex = 5;
            this.lbDI3.Text = "●";
            // 
            // lbThree
            // 
            this.lbThree.AutoSize = true;
            this.lbThree.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbThree.Location = new System.Drawing.Point(234, 153);
            this.lbThree.Name = "lbThree";
            this.lbThree.Size = new System.Drawing.Size(29, 29);
            this.lbThree.TabIndex = 4;
            this.lbThree.Text = "3";
            // 
            // lbDI2
            // 
            this.lbDI2.AutoSize = true;
            this.lbDI2.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI2.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI2.Location = new System.Drawing.Point(117, 82);
            this.lbDI2.Name = "lbDI2";
            this.lbDI2.Size = new System.Drawing.Size(80, 56);
            this.lbDI2.TabIndex = 3;
            this.lbDI2.Text = "●";
            // 
            // lbTwo
            // 
            this.lbTwo.AutoSize = true;
            this.lbTwo.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTwo.Location = new System.Drawing.Point(143, 153);
            this.lbTwo.Name = "lbTwo";
            this.lbTwo.Size = new System.Drawing.Size(29, 29);
            this.lbTwo.TabIndex = 2;
            this.lbTwo.Text = "2";
            // 
            // lbDI1
            // 
            this.lbDI1.AutoSize = true;
            this.lbDI1.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDI1.ForeColor = System.Drawing.Color.LightGray;
            this.lbDI1.Location = new System.Drawing.Point(26, 82);
            this.lbDI1.Name = "lbDI1";
            this.lbDI1.Size = new System.Drawing.Size(80, 56);
            this.lbDI1.TabIndex = 1;
            this.lbDI1.Text = "●";
            // 
            // lbOne
            // 
            this.lbOne.AutoSize = true;
            this.lbOne.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold);
            this.lbOne.Location = new System.Drawing.Point(52, 153);
            this.lbOne.Name = "lbOne";
            this.lbOne.Size = new System.Drawing.Size(29, 29);
            this.lbOne.TabIndex = 0;
            this.lbOne.Text = "1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NetConfigMenuItem,
            this.DeviceManaMenuItem,
            this.languageToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1370, 25);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // NetConfigMenuItem
            // 
            this.NetConfigMenuItem.Name = "NetConfigMenuItem";
            this.NetConfigMenuItem.Size = new System.Drawing.Size(68, 21);
            this.NetConfigMenuItem.Text = "网络配置";
            // 
            // DeviceManaMenuItem
            // 
            this.DeviceManaMenuItem.Name = "DeviceManaMenuItem";
            this.DeviceManaMenuItem.Size = new System.Drawing.Size(68, 21);
            this.DeviceManaMenuItem.Text = "设备管理";
            // 
            // languageToolStripMenuItem
            // 
            this.languageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishToolStripMenuItem,
            this.chineseToolStripMenuItem});
            this.languageToolStripMenuItem.Name = "languageToolStripMenuItem";
            this.languageToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.languageToolStripMenuItem.Text = "语言";
            // 
            // englishToolStripMenuItem
            // 
            this.englishToolStripMenuItem.Name = "englishToolStripMenuItem";
            this.englishToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.englishToolStripMenuItem.Text = "英文";
            // 
            // chineseToolStripMenuItem
            // 
            this.chineseToolStripMenuItem.Name = "chineseToolStripMenuItem";
            this.chineseToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.chineseToolStripMenuItem.Text = "中文";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.Model,
            this.toolStripSeparator2,
            this.LocalIP,
            this.toolStripSeparator3,
            this.LocalPort,
            this.toolStripSeparator4,
            this.currLinkNum,
            this.toolStripSeparator5,
            this.DateTimeWeek});
            this.toolStrip1.Location = new System.Drawing.Point(0, 576);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1069, 25);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // Model
            // 
            this.Model.AutoSize = false;
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(200, 22);
            this.Model.Text = "模式：TCP_Server";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // LocalIP
            // 
            this.LocalIP.AutoSize = false;
            this.LocalIP.Name = "LocalIP";
            this.LocalIP.Size = new System.Drawing.Size(200, 22);
            this.LocalIP.Text = "服务端IP：";
            this.LocalIP.Click += new System.EventHandler(this.LocalIP_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // LocalPort
            // 
            this.LocalPort.AutoSize = false;
            this.LocalPort.Name = "LocalPort";
            this.LocalPort.Size = new System.Drawing.Size(200, 22);
            this.LocalPort.Text = "端口号：";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // currLinkNum
            // 
            this.currLinkNum.AutoSize = false;
            this.currLinkNum.Name = "currLinkNum";
            this.currLinkNum.Size = new System.Drawing.Size(220, 22);
            this.currLinkNum.Text = "当前连接数：0";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // DateTimeWeek
            // 
            this.DateTimeWeek.AutoSize = false;
            this.DateTimeWeek.Name = "DateTimeWeek";
            this.DateTimeWeek.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DateTimeWeek.Size = new System.Drawing.Size(200, 22);
            this.DateTimeWeek.Text = "DateTimeWeek";
            this.DateTimeWeek.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1069, 601);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "网络继电器管理软件 V1.0.7";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain2_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain2_Load);
            this.cMS1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbDO15.ResumeLayout(false);
            this.gbDO15.PerformLayout();
            this.gbDO16.ResumeLayout(false);
            this.gbDO16.PerformLayout();
            this.gbDO14.ResumeLayout(false);
            this.gbDO14.PerformLayout();
            this.gbDO13.ResumeLayout(false);
            this.gbDO13.PerformLayout();
            this.gbDO12.ResumeLayout(false);
            this.gbDO12.PerformLayout();
            this.gbDO11.ResumeLayout(false);
            this.gbDO11.PerformLayout();
            this.gbDO10.ResumeLayout(false);
            this.gbDO10.PerformLayout();
            this.gbDO9.ResumeLayout(false);
            this.gbDO9.PerformLayout();
            this.gbDO8.ResumeLayout(false);
            this.gbDO8.PerformLayout();
            this.gbDO7.ResumeLayout(false);
            this.gbDO7.PerformLayout();
            this.gbDO6.ResumeLayout(false);
            this.gbDO6.PerformLayout();
            this.gbDO5.ResumeLayout(false);
            this.gbDO5.PerformLayout();
            this.gbDO4.ResumeLayout(false);
            this.gbDO4.PerformLayout();
            this.gbDO3.ResumeLayout(false);
            this.gbDO3.PerformLayout();
            this.gbDO2.ResumeLayout(false);
            this.gbDO2.PerformLayout();
            this.gbDO1.ResumeLayout(false);
            this.gbDO1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbD016;
        private System.Windows.Forms.Label lbD015;
        private System.Windows.Forms.Label lbD014;
        private System.Windows.Forms.Label lbD013;
        private System.Windows.Forms.Label lbD012;
        private System.Windows.Forms.Label lbD011;
        private System.Windows.Forms.Label lbD10;
        private System.Windows.Forms.Label lbD09;
        private System.Windows.Forms.Label lbD08;
        private System.Windows.Forms.Label lbD07;
        private System.Windows.Forms.Label lbD06;
        private System.Windows.Forms.Label lbD05;
        private System.Windows.Forms.Label lbD04;
        private System.Windows.Forms.Label lbD03;
        private System.Windows.Forms.Label lbD02;
        private System.Windows.Forms.Label lbD01;
        private System.Windows.Forms.Label lbDI1;
        private System.Windows.Forms.Label lbOne;
        private System.Windows.Forms.Label lbDI16;
        private System.Windows.Forms.Label lbSixTeen;
        private System.Windows.Forms.Label lbDI15;
        private System.Windows.Forms.Label lbFifthTeen;
        private System.Windows.Forms.Label lbDI14;
        private System.Windows.Forms.Label lbFourTeen;
        private System.Windows.Forms.Label lbDI13;
        private System.Windows.Forms.Label lbThirTeen;
        private System.Windows.Forms.Label lbDI12;
        private System.Windows.Forms.Label lbTwelve;
        private System.Windows.Forms.Label lbDI11;
        private System.Windows.Forms.Label lbElevent;
        private System.Windows.Forms.Label lbDI10;
        private System.Windows.Forms.Label lbTen;
        private System.Windows.Forms.Label lbDI9;
        private System.Windows.Forms.Label lbNine;
        private System.Windows.Forms.Label lbDI8;
        private System.Windows.Forms.Label lbEight;
        private System.Windows.Forms.Label lbDI7;
        private System.Windows.Forms.Label lbServen;
        private System.Windows.Forms.Label lbDI6;
        private System.Windows.Forms.Label lbSix;
        private System.Windows.Forms.Label lbDI5;
        private System.Windows.Forms.Label lbFive;
        private System.Windows.Forms.Label lbDI4;
        private System.Windows.Forms.Label lbFour;
        private System.Windows.Forms.Label lbDI3;
        private System.Windows.Forms.Label lbThree;
        private System.Windows.Forms.Label lbDI2;
        private System.Windows.Forms.Label lbTwo;
        private System.Windows.Forms.ContextMenuStrip cMS1;
        private System.Windows.Forms.ToolStripMenuItem 保存显示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清除显示ToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.GroupBox gbDO1;
        private System.Windows.Forms.CheckBox cbTimerDO1;
        private System.Windows.Forms.GroupBox gbDO7;
        private System.Windows.Forms.GroupBox gbDO6;
        private System.Windows.Forms.GroupBox gbDO5;
        private System.Windows.Forms.GroupBox gbDO4;
        private System.Windows.Forms.GroupBox gbDO3;
        private System.Windows.Forms.GroupBox gbDO2;
        private System.Windows.Forms.GroupBox gbDO8;
        private System.Windows.Forms.GroupBox gbDO15;
        private System.Windows.Forms.GroupBox gbDO16;
        private System.Windows.Forms.GroupBox gbDO14;
        private System.Windows.Forms.GroupBox gbDO13;
        private System.Windows.Forms.GroupBox gbDO12;
        private System.Windows.Forms.GroupBox gbDO11;
        private System.Windows.Forms.GroupBox gbDO10;
        private System.Windows.Forms.GroupBox gbDO9;
        private System.Windows.Forms.CheckBox cbTimerDO15;
        private System.Windows.Forms.CheckBox cbTimerDO16;
        private System.Windows.Forms.CheckBox cbTimerDO14;
        private System.Windows.Forms.CheckBox cbTimerDO13;
        private System.Windows.Forms.CheckBox cbTimerDO12;
        private System.Windows.Forms.CheckBox cbTimerDO11;
        private System.Windows.Forms.CheckBox cbTimerDO10;
        private System.Windows.Forms.CheckBox cbTimerDO9;
        private System.Windows.Forms.CheckBox cbTimerDO8;
        private System.Windows.Forms.CheckBox cbTimerDO7;
        private System.Windows.Forms.CheckBox cbTimerDO6;
        private System.Windows.Forms.CheckBox cbTimerDO5;
        private System.Windows.Forms.CheckBox cbTimerDO4;
        private System.Windows.Forms.CheckBox cbTimerDO3;
        private System.Windows.Forms.CheckBox cbTimerDO2;
        private System.Windows.Forms.TextBox tbTimerDO15;
        private System.Windows.Forms.TextBox tbTimerDO16;
        private System.Windows.Forms.TextBox tbTimerDO14;
        private System.Windows.Forms.TextBox tbTimerDO13;
        private System.Windows.Forms.TextBox tbTimerDO12;
        private System.Windows.Forms.TextBox tbTimerDO11;
        private System.Windows.Forms.TextBox tbTimerDO2;
        private System.Windows.Forms.TextBox tbTimerDO8;
        private System.Windows.Forms.TextBox tbTimerDO7;
        private System.Windows.Forms.TextBox tbTimerDO6;
        private System.Windows.Forms.TextBox tbTimerDO5;
        private System.Windows.Forms.TextBox tbTimerDO4;
        private System.Windows.Forms.TextBox tbTimerDO3;
        private System.Windows.Forms.TextBox tbTimerDO10;
        private System.Windows.Forms.TextBox tbTimerDO9;
        private System.Windows.Forms.Label laDO15;
        private System.Windows.Forms.Label laDO16;
        private System.Windows.Forms.Label laDO14;
        private System.Windows.Forms.Label laDO13;
        private System.Windows.Forms.Label laDO12;
        private System.Windows.Forms.Label laDO11;
        private System.Windows.Forms.Label laDO10;
        private System.Windows.Forms.Label laDO9;
        private System.Windows.Forms.Label laDO8;
        private System.Windows.Forms.Label laDO7;
        private System.Windows.Forms.Label laDO6;
        private System.Windows.Forms.Label laDO5;
        private System.Windows.Forms.Label laDO4;
        private System.Windows.Forms.Label laDO3;
        private System.Windows.Forms.Label laDO2;
        private System.Windows.Forms.Label laDO1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem NetConfigMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeviceManaMenuItem;

        //在线翻译
        private System.Windows.Forms.ToolStripMenuItem languageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chineseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishToolStripMenuItem;

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel Model;
        private System.Windows.Forms.ToolStripLabel LocalIP;
        private System.Windows.Forms.ToolStripLabel LocalPort;
        private System.Windows.Forms.ToolStripLabel DateTimeWeek;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel currLinkNum;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.Label labelDO15;
        private System.Windows.Forms.Label labelDO16;
        private System.Windows.Forms.Label labelDO14;
        private System.Windows.Forms.Label labelDO13;
        private System.Windows.Forms.Label labelDO12;
        private System.Windows.Forms.Label labelDO11;
        private System.Windows.Forms.Label labelDO10;
        private System.Windows.Forms.Label labelDO9;
        private System.Windows.Forms.Label labelDO8;
        private System.Windows.Forms.Label labelDO7;
        private System.Windows.Forms.Label labelDO6;
        private System.Windows.Forms.Label labelDO5;
        private System.Windows.Forms.Label labelDO4;
        private System.Windows.Forms.Label labelDO3;
        private System.Windows.Forms.Label labelDO2;
        private System.Windows.Forms.Label labelDO1;
        private System.Windows.Forms.Label laDlyDO1;
        private System.Windows.Forms.Label laDlyDO15;
        private System.Windows.Forms.Label laDlyDO16;
        private System.Windows.Forms.Label laDlyDO14;
        private System.Windows.Forms.Label laDlyDO13;
        private System.Windows.Forms.Label laDlyDO12;
        private System.Windows.Forms.Label laDlyDO11;
        private System.Windows.Forms.Label laDlyDO10;
        private System.Windows.Forms.Label laDlyDO9;
        private System.Windows.Forms.Label laDlyDO8;
        private System.Windows.Forms.Label laDlyDO7;
        private System.Windows.Forms.Label laDlyDO6;
        private System.Windows.Forms.Label laDlyDO5;
        private System.Windows.Forms.Label laDlyDO4;
        private System.Windows.Forms.Label laDlyDO3;
        private System.Windows.Forms.Label laDlyDO2;
        private System.Windows.Forms.ComboBox cbMode1;
        private System.Windows.Forms.ComboBox cbMode4;
        private System.Windows.Forms.ComboBox cbMode3;
        private System.Windows.Forms.ComboBox cbMode2;
        private System.Windows.Forms.ComboBox cbMode8;
        private System.Windows.Forms.ComboBox cbMode7;
        private System.Windows.Forms.ComboBox cbMode6;
        private System.Windows.Forms.ComboBox cbMode5;
        private System.Windows.Forms.ComboBox cbMode15;
        private System.Windows.Forms.ComboBox cbMode16;
        private System.Windows.Forms.ComboBox cbMode14;
        private System.Windows.Forms.ComboBox cbMode13;
        private System.Windows.Forms.ComboBox cbMode12;
        private System.Windows.Forms.ComboBox cbMode11;
        private System.Windows.Forms.ComboBox cbMode10;
        private System.Windows.Forms.ComboBox cbMode9;
        private System.Windows.Forms.TextBox txtWaitTime5;
        private System.Windows.Forms.Button btnExcute1;
        private System.Windows.Forms.Button btnExcute15;
        private System.Windows.Forms.Button btnExcute16;
        private System.Windows.Forms.Button btnExcute14;
        private System.Windows.Forms.Button btnExcute13;
        private System.Windows.Forms.Button btnExcute12;
        private System.Windows.Forms.Button btnExcute11;
        private System.Windows.Forms.Button btnExcute10;
        private System.Windows.Forms.Button btnExcute8;
        private System.Windows.Forms.Button btnExcute7;
        private System.Windows.Forms.Button btnExcute6;
        private System.Windows.Forms.Button btnExcute5;
        private System.Windows.Forms.Button btnExcute4;
        private System.Windows.Forms.Button btnExcute3;
        private System.Windows.Forms.Button btnExcute2;
        private System.Windows.Forms.Button btnExcute9;
        private System.Windows.Forms.Label lbWait5;
        private System.Windows.Forms.Label lbSec5;
        private System.Windows.Forms.CheckBox cbWait5;
        private System.Windows.Forms.CheckBox cbWait4;
        private System.Windows.Forms.Label lbWait4;
        private System.Windows.Forms.TextBox txtWaitTime4;
        private System.Windows.Forms.Label lbSec4;
        private System.Windows.Forms.CheckBox cbWait3;
        private System.Windows.Forms.Label lbWait3;
        private System.Windows.Forms.TextBox txtWaitTime3;
        private System.Windows.Forms.Label lbSec3;
        private System.Windows.Forms.CheckBox cbWait2;
        private System.Windows.Forms.Label lbWait2;
        private System.Windows.Forms.TextBox txtWaitTime2;
        private System.Windows.Forms.Label lbSec2;
        private System.Windows.Forms.CheckBox cbWait15;
        private System.Windows.Forms.Label lbWait15;
        private System.Windows.Forms.TextBox txtWaitTime15;
        private System.Windows.Forms.Label lbSec15;
        private System.Windows.Forms.CheckBox cbWait16;
        private System.Windows.Forms.Label lbWait16;
        private System.Windows.Forms.Label lbSec16;
        private System.Windows.Forms.TextBox txtWaitTime16;
        private System.Windows.Forms.CheckBox cbWait14;
        private System.Windows.Forms.Label lbWait14;
        private System.Windows.Forms.TextBox txtWaitTime14;
        private System.Windows.Forms.Label lbSec14;
        private System.Windows.Forms.CheckBox cbWait13;
        private System.Windows.Forms.Label lbWait13;
        private System.Windows.Forms.Label lbSec13;
        private System.Windows.Forms.CheckBox cbWait12;
        private System.Windows.Forms.Label lbWait12;
        private System.Windows.Forms.TextBox txtWaitTime12;
        private System.Windows.Forms.Label lbSec12;
        private System.Windows.Forms.CheckBox cbWait11;
        private System.Windows.Forms.Label lbWait11;
        private System.Windows.Forms.TextBox txtWaitTime11;
        private System.Windows.Forms.Label lbSec11;
        private System.Windows.Forms.CheckBox cbWait10;
        private System.Windows.Forms.Label lbWait10;
        private System.Windows.Forms.TextBox txtWaitTime10;
        private System.Windows.Forms.Label lbSec10;
        private System.Windows.Forms.CheckBox cbWait8;
        private System.Windows.Forms.Label lbWait8;
        private System.Windows.Forms.TextBox txtWaitTime8;
        private System.Windows.Forms.Label lbSec8;
        private System.Windows.Forms.CheckBox cbWait7;
        private System.Windows.Forms.Label lbWait7;
        private System.Windows.Forms.TextBox txtWaitTime7;
        private System.Windows.Forms.Label lbSec7;
        private System.Windows.Forms.CheckBox cbWait6;
        private System.Windows.Forms.Label lbWait6;
        private System.Windows.Forms.TextBox txtWaitTime6;
        private System.Windows.Forms.Label lbSec6;
        private System.Windows.Forms.CheckBox cbWait1;
        private System.Windows.Forms.Label lbWait1;
        private System.Windows.Forms.TextBox txtWaitTime1;
        private System.Windows.Forms.Label lbSec1;
        private System.Windows.Forms.CheckBox cbWait9;
        private System.Windows.Forms.Label lbWait9;
        private System.Windows.Forms.TextBox txtWaitTime9;
        private System.Windows.Forms.Label lbSec9;
        private System.Windows.Forms.TextBox txtWaitTime13;
        private System.Windows.Forms.TextBox tbTimerDO1;
    }
}