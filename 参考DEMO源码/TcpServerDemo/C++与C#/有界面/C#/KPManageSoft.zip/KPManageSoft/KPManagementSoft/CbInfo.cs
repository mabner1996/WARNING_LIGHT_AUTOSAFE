﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KPManagementSoft
{

    /// <summary>
    ///绑定下拉框数据源
    /// </summary>
  public  class CbInfo
    {
        public int Id { get; set; }
        public string  Name { get; set; }
    }
}
