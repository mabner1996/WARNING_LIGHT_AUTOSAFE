﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KPManagementSoft
{
    /// <summary>
    /// 网卡信息
    /// </summary>
    public class CSimpleNetInfo
    {
        public string Description;
        public string IPStr;
    }
}
