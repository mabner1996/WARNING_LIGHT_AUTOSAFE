package TCPServer;
import java.io.*;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.Enumeration;//枚举

//接收线程
public class ServerThread extends Thread
{
    static Socket socket = null;
    InetAddress inetAddress=null;//===========
    TestFormNew test=new TestFormNew();//
     int[]arrList=new int[16];//延时显示
        int[] DOStatus =new int[16];
      int[] DIStatus = new int[16];


    static  OutputStream outputStream = null;//
    static  OutputStreamWriter writer = null;//

    InputStreamReader inputStreamReader = null;//
    BufferedReader bufferedReader = null;//
    static  InputStream inputStream = null;//

    NotifierImpl notifier=new NotifierImpl();//
    Object obj=new Object();
    public ServerThread(Socket socket,InetAddress inetAddress) {

        this.socket = socket;
        this.inetAddress=inetAddress;
        for (int index=0;index<16;index++ )
        {
            arrList[index]=100000;
        }
         //================================
    }
    //关闭客户端
    static public void ListenClose()
    {
        if (socket != null) {
            try
            {
                socket=null;

                socket.close();
            }
            catch (IOException e) {
                System.out.println("出错信息为"+e.toString());
                e.printStackTrace();
            }
        }
    }

    static public void RelayControl(int ch, int action, String strTimer, String waitTimer )
    {
        String infoTest = "AT+STACH" + ch + "="
                + action;
        if (strTimer != null)
        {
            infoTest += "," + strTimer;
        }
        if (waitTimer != null)
        {
            infoTest += "," + waitTimer;
        }
        //===================
        infoTest += "\r\n";

        try
        {
            if(socket!=null)
            {

               OutputStream    outputStreamTest = socket.getOutputStream();
                OutputStreamWriter   writerTest = new OutputStreamWriter(outputStreamTest);
                //System.out.println("服务器发送" + "{'from_client':'" + socket.getInetAddress().getHostAddress() + "','data':'" + infoTest + "'}");
                //===========
                writerTest.write(infoTest);
                writerTest.flush();//
            }
        }
        catch (Exception ex)
        {
            System.out.println("服务器发送命令出错");
        }
    }

    public static String getIpAddress() {
        try {
            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip = null;
            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
                if (netInterface.isLoopback() || netInterface.isVirtual() || !netInterface.isUp()) {
                    continue;
                } else {
                    Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        ip = addresses.nextElement();
                        if (ip != null && ip instanceof Inet4Address) {
                            return ip.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("IP地址获取失败" + e.toString());
        }
        return "";
    }
    //===接收线程==
    @Override
    public void run()
    {
        try {

            try{
                socket.sendUrgentData(0xFF);
            }catch(Exception ex)
            {
                //这里抛出储物哦
                System.out.println("出错信息为bbbbbb");
                //reconnect();
            }


            if(!socket.isConnected()||socket.isClosed()||socket.isInputShutdown())
            {

                return;
            }
            while (socket==null||!socket.isConnected()||socket.isClosed());
            InputStream  inputStream = socket.getInputStream();
            //=======================================
             int number=inputStream.available();//

            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            outputStream = socket.getOutputStream();
           writer = new OutputStreamWriter(outputStream);
            String info = null;//
            KpCommStatus kcs = KpCommStatus.ReadName;
            int timerout=0;
            byte[] bufferRec = new byte[1024];
            //socket.isConnected()==true&&
            StringBuffer sbuff = new StringBuffer();//
            //inputStream.available()>0
            int lenTest=0;

            while (inputStream.read(bufferRec)==-1)
            {
                System.out.println("出错信息为AAAAAA");

            };
            while (((lenTest =inputStream.read(bufferRec))!=-1))//bufferedReader.readLine())!= null
            {
                //sbuff.append(new String(bufferRec, 0, lenTest));
                info= new String(bufferRec, 0, lenTest);                       //sbuff.toString().trim();
                if (info.contains("AT") == true)//
                {
                    kcs = KpCommStatus.Free;
                }
                else if (info.contains("NAME") )
                {
                    kcs = KpCommStatus.ReadName;
                }
                else if (info.contains("STACH"))
                {
                    kcs = KpCommStatus.ReadDOStatus;
                }
                else if (info.contains("OCCH"))
                {
                    kcs = KpCommStatus.ReadDIStatus;
                }
                else
                {
                    kcs = KpCommStatus.OtherCmdStatus;
                }
                switch (kcs)
                {
                    case  Free:
                        if (info.contains("AT") == true)//
                        {
                            String sendDataACK="AT+ACK\r\n";
                            writer.write(sendDataACK);
                            writer.flush();//
                            System.out.println("服务器接收"+"{'from_client':'"+socket.getInetAddress().getHostAddress()+"','data':'"+sendDataACK+"'}");
                        }
                        break;
                    case AT:
                        if (info.contains("OK") == true)
                        {
                            timerout = 0;
                            kcs = KpCommStatus.Free;
                        }
                        else
                        {

                        }
                        break;
                    case ReadName:
                        if (info.contains("NAME:") == true)
                        {

                            timerout = 0;
                            kcs = KpCommStatus.Free;//=================
                            info = info.substring(info.indexOf("NAME:"), info.length() - info.indexOf("NAME:"));
                            String str = info.substring(info.indexOf(":") + 1,  info.trim().length());
                            System.out.println("网络继电器的名称为"+str);//
                        }
                        else
                        {
                        }
                        break;
                    case ReadDIStatus:
                    case ReadDOStatus:
                    {
                        int i = 0;
                        int count = 0;
                        while (info.indexOf("+", i) >= 0)
                        {
                            i = info.indexOf("+", i) + 1;
                            count++;
                        }
                        //========          =========================
                        for (int index = 0; index < count; index++)
                        {
                            if (info.indexOf("+STACH", 0) == 0)
                            {
                                String ch = info.substring(info.indexOf("STACH")+ 5,
                                        info.indexOf(":"));
                                String stastr = "";
                                String timerstr = "";
                                if ((info.indexOf(",") - info.indexOf(":")) == 2)//相差值
                                {
                                    stastr = info.substring(info.indexOf(":") + 1,
                                            info.indexOf(","));
                                    int indexR=info.indexOf("\r");
                                    timerstr = info.substring(info.indexOf(",") + 1,indexR).trim();// - (info.indexOf(",") + 1) ==, info.indexOf("\r\n")
                                    int chNum=Integer.parseInt(ch);
                                    int timerNum=Integer.parseInt(timerstr);
                                    arrList[chNum-1]=timerNum;
                                }
                                else
                                {

                                    //System.out.println("服务器进入次函数"+info);
                                    stastr = info.substring(info.indexOf(":") + 1,
                                            info.indexOf("\r"));//
                                }
                                //============这里是显示DO和DI的选项======
                                int stastrNum=Integer.parseInt(stastr);
                                int chNum=Integer.parseInt(ch);
                                DOStatus[chNum-1]=stastrNum;
                            }
                            else if (info.indexOf("+OCCH_ALL") == 0)
                            {
                                int [] ch = new int[16];
                                int ch_index = 0;//=======
                                String atStr = info.substring(info.indexOf("+OCCH_ALL:") + 10,
                                        info.length());//
                                do
                                {
                                    String strch = atStr.substring(0, 1);
                                    int strchNum=Integer.parseInt(strch);
                                    ch[ch_index++] =strchNum;     //inte           //Convert.ToByte(strch);
                                    DIStatus[ch_index-1]=strchNum;
                                    if (atStr.length() > 3)
                                    {
                                        atStr = atStr.substring(atStr.indexOf(",") + 1,
                                                atStr.length());   //- (atStr.indexOf(",") + 1)
                                    }
                                    else
                                    {
                                        break;
                                    }
                                } while ((info.length() > 3) && (ch_index < 16));
                            }
                            else if (info.indexOf("+OCCH", 0) == 0)
                            {
                                String ch = info.substring(info.indexOf("OCCH") + 4,
                                        info.indexOf(":"));
                                int indexR=info.indexOf("\r");
                                String stastr = info.substring(info.indexOf(":") + 1,
                                        indexR);
                                int chNum=Integer.parseInt(ch);
                                int stastrNum=Integer.parseInt(stastr);
                                DIStatus[chNum-1]=stastrNum;
                            }
                            if (index < (count - 1))
                            {
                                int index_n = info.indexOf("\n", 0) + 1;
                                int len = info.length() - index_n;
                                info = info.substring(index_n);
                            }
                        }

                        try {

                            notifier.registeListener(test, "DIOShow", DOStatus, DIStatus,arrList);
                            notifier.notifyEvents();

                        } finally {
                        }
                    }
                    break;
                    case WriteDOStatus:
                    {
                        kcs = KpCommStatus.Free;
                    }
                    break;
                    case OtherCmdStatus:
                    {
                        kcs = KpCommStatus.Free;
                        timerout = 0;
                    }
                    break;

                    default:
                        kcs = KpCommStatus.Free;
                        //
                        timerout = 0;

                        break;
                }
                //=========================
            }
            //inputStream.reset();
          socket.shutdownInput();

        } catch (IOException e)
        {
            if(SocketlistenThread.ConnetNum>0)SocketlistenThread.ConnetNum--;
            ClearResource();
            System.out.println("出错信息为"+e.toString());//
            //e.printStackTrace();
        } finally {

            if(SocketlistenThread.ConnetNum>0)SocketlistenThread.ConnetNum--;
            ClearResource();
            try {
                if (writer != null) {
                    writer.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (inputStreamReader != null) {
                    inputStreamReader.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                if (socket != null) {
                    socket.close();
                    socket=null;
                }
            } catch (IOException e) {
                System.out.println("出错信息为"+e.toString());
                e.printStackTrace();
            }
        }

    }

    public   void ClearResource()
    {
        DOStatus=new int[16];
        DIStatus=new int[16];
        arrList=new int[16];
        for(int k=0;k<16;k++)        //===================
        {
            arrList[k]=100000;
        }
        notifier.registeListener(test, "DIOShow", DOStatus, DIStatus,arrList);
        notifier.notifyEvents();

    }

}



