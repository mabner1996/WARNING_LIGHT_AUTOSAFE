package TCPServer;
import sun.misc.GC;
import java.awt.*;
import java.io.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public  class SocketlistenThread extends Thread
{

    public static int port = 6000;
    static public Dictionary<String, Socket> dicSocket = new Hashtable<String,Socket>();
    static public Dictionary<String, Thread>dicSocketRecv = new Hashtable<String,Thread>();//接收线程

    public static int ConnetNum = 0;
    public static Thread uD0;
    public static Thread  uDI;

    public static String hostName="127.0.0.1";

    public static int portNum=6000;
    @Override
    public void run() {

        @SuppressWarnings("resource")
        //测试
        ExecutorService threadPool = Executors.newFixedThreadPool(100);
        Properties prop = new Properties();
        InputStream inputStream = null;
        ServerSocket server = null;


        try {
            prop.load(new FileInputStream("config.ini"));
            /* 注释:也可以直接在src/main/resources目录下新建配置文件，但是new FileInputStream("res/myCanal.properties")需要改为new FileInputStream("src/main/resources/myCanal.properties") */

        } catch (FileNotFoundException ex)
        {
            //ex.printStackTrace();//输出
            //如果配置文件被删除则创建
            prop.setProperty("hostName", hostName);
            prop.setProperty("port", "6000");
            try
            {
                prop.store(new BufferedOutputStream(new FileOutputStream("config.ini")),"Save Configs File.");

            } catch (FileNotFoundException f)
            {
                f.printStackTrace();

            } catch (IOException i)
            {
                i.printStackTrace();
            }

        } catch (IOException k)
        {
            k.printStackTrace();

        } finally
        {
            //===============================================
           // hostName= prop.getProperty("hostName");
           //===============================================//String port=prop.getProperty("port");
          // portNum = Integer.parseInt(port);
        }
        try {
            hostName = prop.getProperty("hostName").toString();
            String port=prop.getProperty("port");//
            if(port!="") portNum = Integer.parseInt(port);
            server = new ServerSocket();
            if (hostName != "") server.bind(new InetSocketAddress(hostName, portNum));
            //================    ==================
            String serverIp = ServerThread.getIpAddress();
            if (hostName == "" && serverIp != "") server.bind(new InetSocketAddress(serverIp, portNum));
        }catch (IOException i)
    {
        i.printStackTrace();
        return;
    }
        while (true) {
            try{
                Socket socket = server.accept();
                InetAddress inetAddress = socket.getInetAddress();//
                System.out.println("当前连接的客户端" + socket);
                //String hostIP=inetAddress.();
                String ipStr=inetAddress.getHostName().toString();
                System.out.println("当前连接的客户端IP地址" + ipStr);
                if (!dicSocket.keys().equals(ipStr)) {
                    dicSocket.put(ipStr, socket);
                    ConnetNum++;
                } else {
                    dicSocket.remove(ipStr);
                    Socket socketclose = dicSocket.get(ipStr);
                    socketclose.close();//=========
                    socketclose=null;
                 if(ConnetNum>0)ConnetNum--;
                }
                Runnable runnable = () -> {
                    try {
                        ServerThread thread = new ServerThread(socket, inetAddress);//

                        if (!dicSocketRecv.keys().equals(ipStr)) {
                            dicSocketRecv.put(ipStr, thread);

                        } else//设置移除相关的信息
                            {
                            dicSocketRecv.remove(ipStr);
                            Thread ThreadClose = dicSocketRecv.get(ipStr);
                            ThreadClose.interrupt();
                        }
                        thread.setDaemon(true);  //后台线程
                        thread.start();
                        uD0 = new ReadD0Thread();
                        uD0.setDaemon(true);//后台线程
                        uD0.start();
                        uDI = new ReadDIThread();
                        uDI.setDaemon(true);  //后台线程
                        uDI.start();
                        //==============
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                };
                threadPool.submit(runnable);
            }catch (IOException e)
            {

                e.printStackTrace();
            }
        }
    }


}







