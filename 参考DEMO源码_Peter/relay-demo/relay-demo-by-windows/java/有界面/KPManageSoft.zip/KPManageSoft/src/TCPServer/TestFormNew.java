package TCPServer;

import javax.swing.*;
import java.awt.Panel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import  java.awt.image.*;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Timer;

//=================

public  class TestFormNew  extends Frame{

	/**
	 * Launch the application.
	 */
    /// <summary>
    /// 延时时间列表
    /// </summary>
    public  TestFormNew()
    {
    }

    public static Dictionary<String,TextField> tbListTimer=new Hashtable<String,TextField>();
    public  static Dictionary<String,Label> laDOList=new Hashtable<String,Label>();
	public  static Dictionary<String,Choice>lstchoice=new Hashtable<String,Choice>();

	public static Label lbShowTimeTest=null;
    public static Label lbConnetNumTest=null;

    public static SocketlistenThread  soke=null;
    /// <summary>
    /// 用来记录连接的socket
    /// </summary>
   static   TestFormNew fr = new TestFormNew("网络继电器管理软件 V1.0.7");
	public static void main(String[] args)
	{

       // Toolkit tk=Toolkit.getDefaultToolkit();
       //Image img=tk.getImage("src/img/cion.gif"); /*mouse.gif是你的图标*/
        ImageIcon icon = new ImageIcon("src/img/cion.png");//这里设置相应的图标
        fr.setIconImage(icon.getImage());// 给窗体设置图标方法
        //fr.setIconImage(img);
		fr.setSize(1090, 700);//设置时间==1180
        GridBagLayout gridBagLayout = new GridBagLayout();
        //设置容器
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        fr.setLayout(gridBagLayout);//
        fr.setResizable(false);
        fr.setLocationRelativeTo(null);
		//添加关闭的监听
		fr.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) {

               if(ServerThread.socket!=null) ServerThread.interrupted();//中断线程
                if(SocketlistenThread.uD0!=null)SocketlistenThread.uD0.interrupt();
                if(SocketlistenThread.uDI!=null)SocketlistenThread.uDI.interrupt();
				System.exit(0);
			}
            //============
			public void windowOpened(WindowEvent e)		//自定义WindowOpened的方法
			{
				//==================窗体的打开的事件===================
                configTimeArea(lbShowTimeTest ,lbConnetNumTest);
				System.out.println("窗体被打开");
                SocketlistenThread thread = new SocketlistenThread();//
                thread.setDaemon(true);  //后台线程
                thread.start();

			}

		});
//====================================================================

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth =5;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;


        Label labelOut=new Label();
        labelOut.setText("输出(OUT)");
        labelOut.setFont(new Font("宋体",Font.BOLD,30));//调节字体大小
        labelOut.setAlignment(1);
        gridBagLayout.setConstraints(labelOut, gridBagConstraints);

        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth =3;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        Label labelINPUT=new Label();//
        labelINPUT.setText("输入(INPUT)");
        labelINPUT.setAlignment(1);
        labelINPUT.setFont(new Font("宋体",Font.BOLD,30));//调节字体大小
        gridBagLayout.setConstraints(labelINPUT, gridBagConstraints);

       Panel pan101 = new Panel();
       PanelAddControl(pan101);
       //============================================
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth =1;
        gridBagConstraints.gridheight = 1;

        gridBagConstraints.insets =new Insets(0,0,0,5);
        gridBagConstraints.fill = GridBagConstraints.BOTH;

        gridBagLayout.setConstraints(pan101, gridBagConstraints);

		//============第二个===================================================

		Panel  panel02=new Panel();
		PanelAddControl(panel02);

        gridBagConstraints.gridx = 2;//第二行第二个
        gridBagConstraints.gridy =1;//行数
        gridBagConstraints.gridwidth = 1; //占得行数
        gridBagConstraints.gridheight = 1;//占得列数
        gridBagConstraints.insets =new Insets(0,0,0,0);
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel02, gridBagConstraints);

		Panel  panel03=new Panel();
		PanelAddControl(panel03);


        gridBagConstraints.gridx = 3;//第一行第三个
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.insets =new Insets(0,0,0,0);
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel03, gridBagConstraints);

		Panel  panel4=new Panel();
		PanelAddControl(panel4);
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.insets =new Insets(0,0,0,0);
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel4, gridBagConstraints);

        Panel panelInput=new Panel();
        AddPanelOutput(panelInput);
        gridBagConstraints.gridx = 5; //第二行的第五个
        gridBagConstraints.gridy = 1;


        gridBagConstraints.gridwidth =4 ;//4  原值为
        gridBagConstraints.gridheight = 4;//占四个高度4

        gridBagConstraints.weightx=6; //横向权重===设置成6==分配剩余===原来为6
        gridBagConstraints.weighty=1; //纵向权重

        //==================================
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panelInput, gridBagConstraints);


		Panel  panel5=new Panel();
		PanelAddControl(panel5);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel5, gridBagConstraints);

		Panel  panel6=new Panel();
		PanelAddControl(panel6);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel6, gridBagConstraints);

        //==================================
		Panel  panel7=new Panel();
		PanelAddControl(panel7);
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel7, gridBagConstraints);



		Panel  panel8=new Panel();
		PanelAddControl(panel8);

        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel8, gridBagConstraints);

		Panel  panel9=new Panel();
		PanelAddControl(panel9);


        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel9, gridBagConstraints);

		Panel  pane10=new Panel();
		PanelAddControl(pane10);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(pane10, gridBagConstraints);

		Panel  pane0l1=new Panel();
		PanelAddControl(pane0l1);

        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(pane0l1, gridBagConstraints);//


		Panel  panel012=new Panel();
		PanelAddControl(panel012);

        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel012, gridBagConstraints);//


		Panel  panel013=new Panel();
		PanelAddControl(panel013);
        gridBagConstraints.gridx =1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel013, gridBagConstraints);//


		Panel  panel014=new Panel();
		PanelAddControl(panel014);
        gridBagConstraints.gridx =2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel014, gridBagConstraints);//



		Panel  panel015=new Panel();
		PanelAddControl(panel015);
        gridBagConstraints.gridx =3;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel015, gridBagConstraints);//


		Panel  panel016=new Panel();
		PanelAddControl(panel016);

        gridBagConstraints.gridx =4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panel016, gridBagConstraints);//

        //添加五个控件
        Panel panelBottom=new Panel();
        //TestFormNew fr=new TestFormNew();


        AddPanelBottom(panelBottom);//
        gridBagConstraints.gridx =1;
        gridBagConstraints.gridy = 5;//第六行
        gridBagConstraints.gridwidth=8;//第五行
        gridBagConstraints.gridheight = 1;//占1个高度
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(panelBottom, gridBagConstraints);//

        //================添加控件=========================
        fr.add(labelOut);
        fr.add(labelINPUT);
        fr.add(pan101);
        fr.add(panel02);
        fr.add(panel03);
        fr.add(panel4);
        fr.add(panelInput);
        fr.add(panel5);
        fr.add(panel6);
        fr.add(panel7);
        fr.add(panel8);
        fr.add(panel9);
        fr.add(pane10);
        fr.add(pane0l1);
        fr.add(panel012);
        fr.add(panel013);
        fr.add(panel014);
        fr.add(panel015);
        fr.add(panel016);
        fr.add(panelBottom);
		fr.setVisible(true);
	}
   //===============增加panel的底部======================


	//====================== ===========

	//static String pathStr=
   public  static void AddPanelBottom(Panel panel)
   {
       //================     ======================

       panel.setLayout(new GridLayout(1,5));//一行五列
       //===============================================
       Label  lbMode=new Label();
       lbMode.setText("模式：TCP_Server");
       lbMode.setFont(new Font("宋体",Font.BOLD,15));//调节字体大小
       panel.add(lbMode);
       //==============================
       Label  lbServerIP=new Label();
       lbServerIP.setText("服务端IP：");//
       String ServerIp=ServerThread.getIpAddress();
       String hostName="127.0.0.1";
       int portNum=6000;
       //=============
       //static pathStr=path.toString();

       String path = fr.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
       int indexR=path.indexOf("out/");
       //String path
       Properties prop = new Properties();//属性值

           InputStream inputStream = null;
           ServerSocket server=null;
           try {
               //加载资源
               prop.load(new FileInputStream("config.ini"));

           }catch (FileNotFoundException ex)
           {
               //ex.printStackTrace();//输出
               //如果配置文件被删除则创建
               if(ServerIp!="")hostName=ServerIp;
               prop.setProperty("hostName", hostName);
               prop.setProperty("port", "6000");
               try
               {
                   prop.store(new BufferedOutputStream(new FileOutputStream("config.ini")),"Save Configs File.");

               } catch (FileNotFoundException f)
               {
                   f.printStackTrace();

               } catch (IOException i)
               {
                   i.printStackTrace();
               }

           } catch (IOException k)
           {
               k.printStackTrace();
           }

       //=============    ===============================
       hostName= prop.getProperty("hostName").toString();//============
       String portStr=prop.getProperty("port");
       portNum = Integer.parseInt(portStr);
       boolean isPorUse=false;
try {
     isPorUse = isPortUsing(hostName, portNum);

}catch (UnknownHostException e)
{

}

       if(hostName!="")ServerIp=hostName;//赋值
       lbServerIP.setText(lbServerIP.getText()+ServerIp);//设置当前当前的IP
       lbServerIP.setFont(new Font("宋体",Font.BOLD,15));//调节字体大小
       panel.add(lbServerIP);
       //==========================
       Label  lbPort=new Label();
       lbPort.setText("端口：");//
       lbPort.setFont(new Font("宋体",Font.BOLD,15));//调节字体大小
       //==============设置端口===============
       if(portNum!=6000)SocketlistenThread.port=portNum;
       lbPort.setText(lbPort.getText()+ SocketlistenThread.port);//

       if(isPorUse==true)lbPort.setForeground(Color.red);
       panel.add(lbPort);
       //==================  ====================
       Label lbConectNum=new Label("当前连接数:");
       lbConectNum.setFont(new Font("宋体",Font.BOLD,15));//调节字体大小
       lbConnetNumTest=lbConectNum;
       panel.add(lbConectNum);
       //==========================================
       Label lbShowTime=new Label();
       lbShowTime.setFont(new Font("宋体",Font.BOLD,15));//调节字体大小
       lbShowTimeTest=lbShowTime;
       panel.add(lbShowTime);
   }
	//================================================
	public static  void AddPanelOutput(Panel panel)
	{
	    panel.setLayout(new GridLayout(8,4,35,0));//5
	   for (int i=0;i<=3;i++)
	  {
		for (int j=4*i+1;j<=4*i+4;j++)
		{
		 Label lbDI=AddLableNew(panel,"lbDI"+j); //添加上面的图标

		}
         for (int k=4*i+1;k<=4*i+4;k++)
         {
             AddLableNew(panel,"lbNumber"+k);//添加下面的图标
         }
	 }
	}
   public   static void DIOShow(int[] DOStatus, int[] DIStatus,int[]arrAy)
	{

            for (int i = 0; i < 16; i++)
			{
				if (DOStatus[i] > 0)
				{
					Label lblD0=DOList.get("lbD0"+(i));//
                    if(lblD0!=null) {
                        Color color=lblD0.getForeground();
                        if(color.equals(Color.lightGray))
                        {
							lblD0.setForeground(Color.green);
                        };
                    };
				}
				else
				{
					String keyName= "lbD0"+i;
					Label lblD02=DOList.get("lbD0"+(i));//
					//
                    if(lblD02!=null)
                    {
                        Color color=lblD02.getForeground();
                       if(color.equals(Color.green))
                       {
						   lblD02.setForeground(Color.lightGray);
                       };
                    }
				}
             //=================显示DI==================
				if (DIStatus[i] > 0) {
                    Label lblDI = DIList.get("lbDI" + (i+1));
                    if (lblDI != null) {
                        Color color=lblDI.getForeground();
                        if(color!=Color.green) {
							lblDI.setForeground(Color.green);
                        };
                    }
                }
				else
				{
					Label lblDI2=DIList.get("lbDI"+(i+1));//
                    if(lblDI2!=null)
                    {
                        Color color=lblDI2.getForeground();
                        if(color!=Color.lightGray) {
							lblDI2.setForeground(Color.lightGray);
                        }

                    }
				}
				//=================显示延时倒计时=========================
                Label label=laDlyDOList.get("laDlyDO"+(i));
                int iTime = arrAy[i];
                if ((iTime != 0) && (iTime != 100000))
                {
                    //System.out.println("当前的获取到的延时时间"+timer);
                    if(label!=null)
                    {

                        boolean isVisible=label.isVisible();//减少重绘
                        if(!isVisible)
                        {
                            label.setVisible(true);
                            fr.repaint();
                            fr.setVisible(true);

                        }
                        label.setText(String.valueOf(iTime));

                    }
                }
                else
                {
                    if(label!=null)
                    {
                        label.setVisible(false);
                    }
                }
			}

	}

    //注册事件=======
	static   class ButtonHandler implements ActionListener {       //实现接口ActionListener才能充当事件ActionEvent的处理者
		public void actionPerformed(ActionEvent e)
		{         //系统产生的ActionEvent事件对象被当前做参数传递给该方法

			String name=e.getActionCommand();
			String strTimer=null;
            String waitTime=null;
			name=name.substring(9);

			int number= Integer.parseInt(name);
			number++;
			TextField textWait=txtListWaitTime.get("txtWaitTime"+(number-1));
			if(textWait.isVisible()==true)waitTime=textWait.getText();

			if(waitTime!=null)System.out.println( "waitTime"+waitTime);

           //=================================================================
			String tbTimerNumber=""+(number-1);
			TextField  txttbTimer=tbListTimer.get("tbTimer"+tbTimerNumber);
			//===========================================
			if(txttbTimer!=null&&txttbTimer.isVisible())strTimer=txttbTimer.getText();
			int action=0;
            Choice choice=lstchoice.get("cbMode"+(number-1));
            if(choice!=null)action=choice.getSelectedIndex();
            if(ServerThread.socket==null)//==========
            {
                JOptionPane.showMessageDialog(null, "当前设备未连接","操作错误",JOptionPane.ERROR_MESSAGE);
            }
			ServerThread.RelayControl(number,action,strTimer,waitTime);

		}
	}
	public TestFormNew(String str) {
		super(str);//构造函数
	}

	public static void PanelAddControl(Panel panel)
	{

        GridBagLayout gridBagLayout = new GridBagLayout();
        //设置容器
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        panel.setLayout(gridBagLayout);
		String panelName=panel.getName();
		String Name=panelName.substring(5);
		//==============int number=int.===========
        Label label= AddLableNew(panel,"lbSnNumber"+Name);//第一个
        gridBagConstraints.gridx=0;//第一行第一列
        gridBagConstraints.gridy=0;

        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(label,gridBagConstraints);


        Label lbD0=AddLableNew(panel,"lbD0"+Name);//第一个
        gridBagConstraints.gridx=1;//第一行第一列
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(lbD0,gridBagConstraints);//这里

		//测试 添加按钮
	    Choice cbMode=AddChoice(panel,"cbMode"+Name);//第二个和第三个
        gridBagConstraints.gridx=2;//第一行第一列
        gridBagConstraints.gridy=0;
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=2;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.insets=new Insets(0, 0, 0, 0);
        gridBagLayout.setConstraints(cbMode,gridBagConstraints);

     Label  laDlyDO=  AddLableNew(panel,"laDlyDO"+Name); //图标下面的倒计时第四个

        gridBagConstraints.gridx=1;//第一行第一列
        gridBagConstraints.gridy=1;
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.insets=new Insets(0, 0, 0, 0);
        gridBagLayout.setConstraints(laDlyDO,gridBagConstraints);

	    Button btnExcute=AddButton(panel,"btnExcute"+Name);//第五个//第六个

        gridBagConstraints.gridx=2;//第一行第一列
        gridBagConstraints.gridy=1;
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=2;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.insets=new Insets(0, 0, 5, 0);

        gridBagLayout.setConstraints(btnExcute,gridBagConstraints);

	    Label labelDO=AddLableNew(panel,"labelDO"+Name);//第7个延时
        gridBagConstraints.gridx=1;//第一行第一列
        gridBagConstraints.gridy=2;
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(labelDO,gridBagConstraints);


	    TextField tbTimer=	AddTextField(panel,"tbTimer"+Name);//第八个文本框
        gridBagConstraints.gridx=2;//第一行第一列
        gridBagConstraints.gridy=2;//
        gridBagConstraints.gridheight=1; //========
        gridBagConstraints.gridwidth=1;  //========
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.insets=new Insets(0, 0, 5, 0);
        gridBagLayout.setConstraints(tbTimer,gridBagConstraints);


	    Label laDO=AddLableNew(panel,"laDO"+Name);//第九个延时单位秒 =====
        gridBagConstraints.gridx=3;//第一行第一列
        gridBagConstraints.gridy=2;//
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(laDO,gridBagConstraints);

	    Label lbWait=AddLableNew(panel,"lbWait"+Name);//第十个
        gridBagConstraints.gridx=1;//第一行第一列
        gridBagConstraints.gridy=3;//
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(lbWait,gridBagConstraints);

	TextField txtWaitTime=AddTextField(panel,"txtWaitTime"+Name);//第八个文本框
        gridBagConstraints.gridx=2;//第一行第一列
        gridBagConstraints.gridy=3;//
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
       // panel.add(txtWaitTime);
        gridBagLayout.setConstraints(txtWaitTime,gridBagConstraints);


	    Label lbSec=AddLableNew(panel,"lbSec"+Name);                   //AddLableNew(panel,"lbSec"+Name);//第十个
        gridBagConstraints.gridx=3;//第一行第一列
        gridBagConstraints.gridy=3;//
        gridBagConstraints.gridheight=1;
        gridBagConstraints.gridwidth=1;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagLayout.setConstraints(lbSec,gridBagConstraints);
        panel.setVisible(true);


	}

    private static int ONE_SECOND = 1000; //一秒钟刷新一次
    private static String time;
    public static Label   displayArea;
    public static Label   lbConectNumTest;

    //显示时间和连接数
    private static void configTimeArea(Label lbShowTime,Label lbConectNum) {
        Timer tmr = new Timer();
        displayArea=lbShowTime;
        lbConectNumTest=lbConectNum;
        tmr.scheduleAtFixedRate(new JLabelTimerTask(), new Date(), ONE_SECOND);
    }

    protected static class JLabelTimerTask extends TimerTask {
        SimpleDateFormat dateFormatter = new SimpleDateFormat
                (
                "yyyy-MM-dd HH:mm:ss");
        @Override
        public void run() {
            time = dateFormatter.format(Calendar.getInstance().getTime());
            //=====获取周几的显示=============================================
            String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
            Calendar cal = Calendar.getInstance();
            cal.setTime(Calendar.getInstance().getTime());
            int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
            if (w < 0)
                w = 0;
            time=time +weekDays[w];
            displayArea.setText(time);
            //设置连接数
            if(lbConectNumTest!=null) lbConectNumTest.setText("当前连接数:" + SocketlistenThread.ConnetNum);
        }
    }
   //等待的lab值
    static Dictionary<String,Label> lstWait=new Hashtable<String,Label>() ;
    /// <summary>
    /// DO延时时间显示
    /// </summary>
   static Dictionary<String,Label> laDlyDOList=new Hashtable<String,Label>();


    /// <summary>
    /// 等待时间秒的显示
    /// </summary>
    static Dictionary<String,Label> lstSec=new Hashtable<String,Label>();

    /// <summary>
    /// 等待时间列表
    /// </summary>
    static Dictionary<String,TextField> txtListWaitTime=new Hashtable<String,TextField>();

    /// <summary>
    ///字体延时
    /// </summary>
    static Dictionary<String,Label> lstdlyTime=new Hashtable<String,Label>();



    /// <summary>
    /// DI显示列表
    /// </summary>
    private static Dictionary<String,Label> DIList=new Hashtable<String,Label>();

    /// <summary>
    /// 设置相应的Lable图标
    /// </summary>
    private static Dictionary<String,Label> DOList=new Hashtable<String,Label>() ;

   //=====获取Lable=============
	public static Label  AddLableNew(Panel panel,String labName)
	{
		Label lb1=new Label();
		lb1.setAlignment(2);
        lb1.setVisible(false);
		if(labName.contains("lbD0")||labName.contains("lbDI"))
		{
		    //====================================
			lb1.setText("●");
			lb1.setSize(50,50);
            lb1.setVisible(true);
            lb1.setAlignment(0);
			lb1.setForeground(Color.lightGray);
          if(labName.contains("lbD0"))
          {
              lb1.setFont(new Font("宋体",Font.BOLD,40));//调节字体大小
              DOList.put(labName, lb1);
          }
          if(labName.contains("lbDI"))
          {

              lb1.setFont(new Font("宋体",Font.BOLD,50));//调节字体大小
              lb1.setAlignment(0);
              DIList.put(labName, lb1);
          };

		}else if(labName.contains("laDO")||labName.contains("lbSec"))
		{
			lb1.setText("秒");
			lb1.setAlignment(0);
           if(labName.contains("laDO"))
           {
               laDOList.put(labName,lb1);//添加到这个laDO列表下
           }
           else
               {
               lstSec.put(labName,lb1);
              }
		}else if (labName.contains("labelDO"))
		{
			lb1.setText("延时");//

            lstdlyTime.put(labName,lb1);

		}else if (labName.contains("lbWait"))
		{
			lb1.setText("等待");//
           lstWait.put(labName,lb1);

		}else if(labName.contains("lbNumber"))//右边的输出面板的需要
		{
			String lbText=labName.substring(8);
            lb1.setText(lbText);//
            lb1.setFont(new Font("宋体",Font.BOLD,30));
            lb1.setAlignment(1);//设置居中先
			lb1.setVisible(true);
		}else if(labName.contains("laDlyDO"))
		{
			//为不可见
            lb1.setAlignment(1);//设置居中先
			laDlyDOList.put(labName,lb1);

		}else if(labName.contains("lbSnNumber"))
        {
            System.out.println("进入lbSnNumber"+labName);
            lb1.setAlignment(2);//设置居右边
            String Number=labName.substring(10);
            int lbNumber=0;
            try {
                 lbNumber=Integer.parseInt(Number);
                lbNumber++;
            } catch (Exception e) {
                e.printStackTrace();
            }
            lb1.setText(String.valueOf(lbNumber));
            lb1.setFont(new Font("宋体",Font.BOLD,20));
            lb1.setVisible(true);
        }
		lb1.setName(labName);
		panel.add(lb1);
		return lb1;
	}

	public static Button  AddButton( Panel panel, String buttonName)
	{

		Button btn=new Button();
		btn.setName("btnExcute"+buttonName);
        btn.setSize(10,10);
		btn.setLabel("执行");

		btn.setActionCommand(buttonName);
		btn.addActionListener(new ButtonHandler());
		panel.add(btn);

		return btn;
	}
	//
	public static  Choice  AddChoice(Panel panel,String choiceName)
	{
         //
		Choice choice=new Choice();
		choice.setName(choiceName);
		choice.add("自锁关");
		choice.add("自锁开");
		choice.add("点动关");
        choice.add("点动开");
		choice.add("互锁延时");
		choice.add("互锁点动");
		choice.add("循环");
		lstchoice.put(choiceName,choice);
		choice.addItemListener((ItemListener) new ChoiceExample());
		panel.add(choice);
		return  choice;

	}

	//====================================================================
	public  static  TextField AddTextField(Panel panel,String textFieldName)
	{
		//========================================
		TextField txtName=new TextField();
        txtName.setVisible(false);
		txtName.setText("");
		txtName.setName(textFieldName);
		if(textFieldName.contains("txtWaitTime"))
        {
            txtListWaitTime.put(textFieldName,txtName);
        }else if(textFieldName.contains("tbTimer"))
        {
         tbListTimer.put(textFieldName,txtName);
        }
        txtName.setSize(10,10);
		panel.add(txtName);
           return txtName;
	}
	//
	public static void SetControlState(boolean isTrue,String cbName)
    {
        Label labDO= lstdlyTime.get("labelDO"+cbName);
        labDO.setVisible(isTrue);
        Label lbSec=lstSec.get("lbSec"+cbName);//等待==秒
        if(lbSec!=null)lbSec.setVisible(isTrue);

        Label lbWait=lstWait.get("lbWait"+cbName);//延时秒
        if(lbWait!=null)lbWait.setVisible(isTrue);

        TextField textWait=txtListWaitTime.get("txtWaitTime"+cbName);
        if(textWait!=null)textWait.setVisible(isTrue);
        if(isTrue&&textWait!=null)
        {
            textWait.setText("99999");
        }

        //==================================================
        TextField  txttbTimer=tbListTimer.get("tbTimer"+cbName);
        if(txttbTimer!=null)txttbTimer.setVisible(isTrue);
        if(isTrue&&txttbTimer!=null)
        {
            txttbTimer.setText("99999");
        }
        Label labDOTest=  laDOList.get("laDO"+cbName);
        if(labDOTest!=null)labDOTest.setVisible(isTrue);
    }

    //互锁延时和（点动开，点动关互斥）
    /*Choice下拉式菜单，产生Choice对象，向Choice里添加选项，检查哪个选项被选择，
     * 侦测Choice的是ItemListener，必须向它注册，并实现里面的itemStateChanged方法*/
    public  static   class ChoiceExample implements ItemListener
    {
        //事件的方法
        public void itemStateChanged(ItemEvent e) {

            Choice c = (Choice) e.getSource();
            String choiceName = c.getName();
            String cbName="";
            if (choiceName.length() > 6)
            {
                cbName=choiceName.substring(6);
            }
            //
            int selectIndex=c.getSelectedIndex();
  if (selectIndex==6||selectIndex==5)//
{
    SetControlState(true, cbName);

}else if(selectIndex == 4)//
{

    Label labDO= lstdlyTime.get("labelDO"+cbName);
    labDO.setVisible(false);

    Label labDOTest=  laDOList.get("laDO"+cbName);
    if(labDOTest!=null)labDOTest.setVisible(false);

    TextField  txttbTimer=tbListTimer.get("tbTimer"+cbName);
    if(txttbTimer!=null)txttbTimer.setVisible(false);


    Label lbSec=lstSec.get("lbSec"+cbName);//等待==秒
    if(lbSec!=null)lbSec.setVisible(true);

    Label lbWait=lstWait.get("lbWait"+cbName);//延时秒
    if(lbWait!=null)lbWait.setVisible(true);

    TextField textWait=txtListWaitTime.get("txtWaitTime"+cbName);
    if(textWait!=null) {
        textWait.setText("99999");//
        textWait.setVisible(true);
    };

}else if(selectIndex == 0 || selectIndex == 1|| selectIndex == 7)
{
    SetControlState(false, cbName);

}else
    {
        Label labDO= lstdlyTime.get("labelDO"+cbName);
        labDO.setVisible(true);

        Label labDOTest=  laDOList.get("laDO"+cbName);
        if(labDOTest!=null)labDOTest.setVisible(true);

        TextField  txttbTimer=tbListTimer.get("tbTimer"+cbName);
        if(txttbTimer!=null)
        {
            txttbTimer.setText("99999");//
            txttbTimer.setVisible(true);
        };
        Label lbSec=lstSec.get("lbSec"+cbName);//等待==秒
        if(lbSec!=null)lbSec.setVisible(false);

        Label lbWait=lstWait.get("lbWait"+cbName);//延时秒
        if(lbWait!=null)lbWait.setVisible(false);

        TextField textWait=txtListWaitTime.get("txtWaitTime"+cbName);
        if(textWait!=null)textWait.setVisible(false);
    }

            fr.setVisible(true);
            fr.invalidate();
            fr.repaint();
        }

    }


    /***
     * 测试主机Host的port端口是否被使用
     * @param host
     * @param port
     * @throws
     */
    public static boolean isPortUsing(String host,int port) throws UnknownHostException {
        boolean flag = false;
        InetAddress Address = InetAddress.getByName(host);
        try {
            Socket socket = new Socket(Address,port);  //建立一个Socket连接
            flag = true;//端口未被使用
        } catch (IOException e)
        {
        }
        return flag;
    }
}




