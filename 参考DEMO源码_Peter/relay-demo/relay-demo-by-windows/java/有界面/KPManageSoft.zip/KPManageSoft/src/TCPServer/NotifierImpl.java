package TCPServer;
///===========================委托=============================
public class NotifierImpl extends NotifierAbstract {
    @Override
    public void registeListener(Object object, String methodName, Object... args) {
        //System.out.println("有新的方法注册到委托类中了，实现类为：" + object.getClass().getName());
        this.getEventHandler().registeEvent(object, methodName, args);
    }
    //==========唤醒通知=====================
    @Override
    public void notifyEvents() {
        //System.out.println("唤起委托下的所有实现类");
        try {
            this.getEventHandler().notifiy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
