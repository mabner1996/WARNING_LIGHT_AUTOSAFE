package TCPServer;

import java.util.ArrayList;
import java.util.List;

public class EventHandler {
    private List<Event> events;

    public EventHandler() {
        events = new ArrayList<Event>();//执行成时间的方法
    }
    //=============          ================================================
    public void registeEvent(Object object, String methodName, Object... args){
        //===============  =======================================
        Event event=new Event(object, methodName, args);

        if(!events.contains(event)) {
            //System.out.println("将类" + object.getClass().getName() + "委托给EventHandler");
            this.events.add(new Event(object, methodName, args));
        }
        else

            {
                events.remove(event);//如何包含的的话就移除该事件
        }
    }

    public void notifiy() throws Exception{

       for(Event e : events){
            e.invoke();
     }
    }
}
