package TCPServer;

import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class ReadDIThread extends Thread{

    @Override
    public void run() {
        //如果没有选择设备，不能往下执行
        while (ServerThread.socket == null||!ServerThread.socket.isConnected()||ServerThread.socket.isClosed()) ;

        String atCmd = "AT+OCCH0=?\r\n";//读取所有
        //=====================================
        while (true)
        {
            try
            {
                while (ServerThread.socket == null);
               // while (ServerThread.socket == null||!ServerThread.socket.isConnected()||ServerThread.socket.isClosed());
                if (ServerThread.socket!=null&&ServerThread.socket.isConnected()==true)
                {
                    OutputStream outputStream = null;//
                    OutputStreamWriter writer = null;//
                    outputStream = ServerThread.socket.getOutputStream();
                    writer = new OutputStreamWriter(outputStream);

                    //System.out.println("服务器发送" + "{'from_client':'" + ServerThread.socket.getInetAddress().getHostAddress() + "','data':'" + atCmd + "'}");
                    //===========
                    writer.write(atCmd);
                    writer.flush();//
                }
                //30ms发送一次==每次发送
                ReadD0Thread.sleep(300);//300
            }
            catch (Exception e)//==================
            {

                //发送D0 读取错误====================================
            }
        }
    }


}
